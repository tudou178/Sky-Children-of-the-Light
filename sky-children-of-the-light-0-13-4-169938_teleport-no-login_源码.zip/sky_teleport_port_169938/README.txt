Sky 0.13.4 (169938) 地图传送 · 无登录门槛版
==========================================

安装包：E:\sky-children-of-the-light-0-13-4-169938_teleport-no-login.apk
说明：E:\sky-children-of-the-light-0-13-4-169938_teleport-no-login_说明.txt
源码：E:\sky-children-of-the-light-0-13-4-169938_teleport-no-login_源码.zip

本版已移除 Mod 自己的“先登录”检查；选图请求不依赖账号状态。
未登录时也可提交选图，本地引擎和资源就绪后使用原 Mod 的换图调用方式。
重要：尚未验证真机上的未登录实际换图、角色操控或登录界面消失。
这不是官方免登录授权，也不是完整离线游戏或本地服务器。

使用方法
--------
1. 安装并启动新版 APK。提交选图不要求先登录账号。
2. 游戏界面左侧有“传送”按钮，可按住拖动位置。
3. 点击按钮，搜索中文地图名或英文内部名，点击地图。
4. 选图后面板关闭；请求由游戏线程处理，不在界面线程直接强制加载。
5. 再次打开面板可以查看当前地图和请求状态。

状态说明
--------
- “已选择”表示请求已排队；“已提交原版换图事件”也不等于已经换图成功。
- 本地引擎初始化、资源加载、游戏暂停或原版切图期间，会暂存选图并等待。
  等待期间再次选图，以最后一次选择为准；执行后有两秒冷却。
- 若未暂停且引擎一直未就绪，约 60 秒后提示等待超时，可重新选图。
- 地图 bundle 不可用或原版认为地图不存在时会拒绝执行，不强行绕过资源检查。
- 原版登录错误界面、剧情/特殊地图限制和全局禁用换图事件的设置仍然保留。

地图与实现范围
--------------
列表动态读取当前安装包的 assets/Data/Levels，仅显示含非空 Resources.lua
且内部名有效的地图；本目标 APK 共 51 张。中文名只是显示标签，不是固定列表。
沿用 MineSky 的 CheckpointBarn::m_ChangeLevel(nullptr, Game*, level) 调用方式，
已适配原版 169938。原版流程为换图事件 -> 淡入淡出 -> QueueLevel -> LevelLoad。
支持本地 GameMode Ready=2 / Running=3；这些值不是账号登录状态。

只 Hook Game::UpdateSync，保留原函数执行和返回值。
Mod 不检查 AccountBarn::IsReady，不伪造账号、登录会话或本地角色，
不调用 LoginSync，不改服务器地址，不添加 TLS 绕过、私服启动器或本地游戏服务器。
原版自身联网流程不变；联网、存档同步和角色是否可操作不在本版保证范围内。

安装注意
--------
包名 com.tgc.sky.android，版本 0.13.4 (169938)，ARM64 / Android 8.0+。
新版与上一版 teleport-only 使用相同的 Mod 签名证书；官方签名的同包名应用
通常不能直接覆盖安装。遇到签名冲突，先确认账号已绑定且重要数据已备份，
再自行决定如何处理旧应用；本次没有安装/卸载应用，也没有清除数据。
旧官方服务是否接受这个版本、第三方登录是否接受重签名应用，取决于服务端。

复核与校验（2026-11-07）
-----------------------
- 官方 apksigner 验证通过：APK Signature Scheme v2 / v3；zipalign 对齐通过。
- 全部 ZIP 条目 CRC 校验通过，5155 个原文件内容保留，包括原版 DEX、游戏库和资源。
- 清单只替换 Application 类名，新增类先调用原 TGCApplication 的 onCreate；原启动页未替换。
- 新增 classes3.dex、libskyteleport.so 和 shadowhook 1.0.7 依赖；移除旧 SourceStamp 元数据。
- 原 APK 的 Music_AP11.streams.bank 有 CRC 错误：只修正 ZIP 校验值，音频字节未改。
- 42 项检查通过：41 项新增库 ARM64 模拟执行场景，加 1 项 Java 源码检查。
  Android/JNI/原版游戏函数均使用测试桩；没有执行完整原版引擎或官方服务。
- 独立检查成品 DEX：直接调用 nativeRequest、无 nativeReady 门槛、动态读取 51 张地图。
- 本轮重新编译的新增原生库和 DEX 与 APK 内对应文件逐字节一致；未重打包或覆盖 APK。
- 通过实际 IDA 9.3 MCP 复核初始化、GameMode、资源条件和换图 ABI；IDA 数据库无字节 patch。
- 尚未进行设备实测；以上结果不能作为“未登录真机换图已成功”的证明。

APK SHA-256
-----------
9bac052a2730753bd7147758a8973522e4abc59e5a0be1651120370028a69854

源码与复核记录
--------------
工作目录：D:\工具\其他\ai\sky_teleport_port_169938
最新复核：IDA_NO_LOGIN_REVIEW.md、ida_no_login_review.json
构建说明：BUILD.md；校验：verification.json、native_tests.json、build_environment.json
源码包不含原 APK/游戏资源、IDA 数据库、签名私钥或大体积 JDK/SDK/NDK。

旧版 teleport-only APK、旧说明和旧源码 ZIP 保留未覆盖。
IDA_MCP_REVIEW.md 与 README_teleport-only_history.txt 是旧版历史记录，不是新版使用说明。
IDA/MCP 仍在后台运行，接口只监听 http://127.0.0.1:13337/mcp。
Start-IdaMcp.ps1 仅未提权时请求正常 UAC；本轮已有管理员权限，未再提权。
MCP 仅用于本机静态分析，不加入 APK，也不是游戏服务器。本轮未调用 ADB。
