﻿param([string]$IdaExe = 'C:\Program Files\IDA Professional 9.3\ida.exe')
$ErrorActionPreference = 'Stop'
$w = $PSScriptRoot
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'RemoteSigned', '-File', ('"' + $PSCommandPath + '"'))
    Write-Output 'Requested normal UAC elevation; run the script in the approved elevated window.'
    exit
}
$port = Get-NetTCPConnection -State Listen -LocalPort 13337 -ErrorAction SilentlyContinue
if ($port) {
    Write-Output ('Port 13337 is already in use by PID ' + $port[0].OwningProcess + '; did not start or stop any process.')
    exit
}
$input = Join-Path $w 'target\lib\arm64-v8a\libBootloader.so'
$db = Join-Path $w 'build\ida\sky169938.i64'
$script = Join-Path $w 'ida_mcp_bootstrap.py'
$log = Join-Path $w 'logs\ida_mcp_ida.log'
New-Item -ItemType Directory -Force -Path (Split-Path $db) | Out-Null
$argsList = @('-TElf', ('-L"' + $log + '"'), ('-S"' + $script + '"'))
if (Test-Path -LiteralPath $db) {
    $argsList += ('"' + $db + '"')
} else {
    $argsList += ('-o"' + $db + '"')
    $argsList += ('"' + $input + '"')
}
$p = Start-Process -FilePath $IdaExe -ArgumentList $argsList -WorkingDirectory $w -WindowStyle Minimized -PassThru
[pscustomobject]@{ProcessId=$p.Id;Elevated=$true;Executable=$IdaExe;Input=$input;Database=$db;Endpoint='http://127.0.0.1:13337/mcp'} | Format-List
