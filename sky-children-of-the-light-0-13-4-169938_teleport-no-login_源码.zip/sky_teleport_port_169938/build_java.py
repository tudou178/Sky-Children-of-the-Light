﻿import pathlib,subprocess,zipfile,os
w=pathlib.Path(__file__).resolve().parent; jdkbin=next((w/'tools/jdk').glob('*/bin'))
android=w/'tools/sdk/android-11/android.jar'; out=w/'build/java'; out.mkdir(exist_ok=True)
sources=list((w/'mod/java').rglob('*.java'))+list((w/'build/stubs').rglob('*.java'))
cmd=[str(jdkbin/'javac.exe'),'-J-Duser.language=en','-J-Dfile.encoding=UTF-8','-encoding','UTF-8','-source','8','-target','8','-Xlint:all','-Werror','-bootclasspath',str(android),'-d',str(out),*[str(p) for p in sources]]
r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); print(r.stdout.decode('utf-8',errors='replace')); print('JAVAC',r.returncode); (w/'logs/java_compile.txt').write_bytes(r.stdout)
if r.returncode: raise SystemExit(r.returncode)
with zipfile.ZipFile(w/'build/modclasses.jar','w',zipfile.ZIP_DEFLATED) as z:
 for p in (out/'sky').rglob('*.class'): z.write(p,p.relative_to(out).as_posix())
with zipfile.ZipFile(w/'build/stubs.jar','w',zipfile.ZIP_DEFLATED) as z:
 for p in (out/'com/tgc/sky').rglob('*.class'): z.write(p,p.relative_to(out).as_posix())
dexout=w/'build/dex'; dexout.mkdir(exist_ok=True)
cmd=[str(jdkbin/'java.exe'),'-Duser.language=en','-Dfile.encoding=UTF-8','-cp',str(w/'tools/sdk/android-14/lib/d8.jar'),'com.android.tools.r8.D8','--release','--min-api','26','--lib',str(android),'--classpath',str(w/'build/stubs.jar'),'--output',str(dexout),str(w/'build/modclasses.jar'),str(w/'tools/shadowhook-classes.jar')]
r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); print(r.stdout.decode('utf-8',errors='replace')); print('D8',r.returncode); (w/'logs/d8_compile.txt').write_bytes(r.stdout)
if r.returncode: raise SystemExit(r.returncode)
print('New DEX:',(dexout/'classes.dex').stat().st_size,'bytes')
