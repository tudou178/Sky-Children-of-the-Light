"""Small JSON-RPC MCP client for a loopback-only IDA server."""
import argparse
import json
import pathlib
import time
import urllib.request

W = pathlib.Path(__file__).resolve().parent
URL = 'http://127.0.0.1:13337/mcp'

class IdaMcpClient:
    def __init__(self, timeout=200):
        self.timeout = timeout
        self.session_id = None
        self.request_id = 0
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def request(self, method, params=None, notification=False):
        self.request_id += 1
        payload = {'jsonrpc': '2.0', 'method': method}
        if not notification:
            payload['id'] = self.request_id
        if params is not None:
            payload['params'] = params
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream'}
        if self.session_id:
            headers['Mcp-Session-Id'] = self.session_id
        req = urllib.request.Request(URL, data=json.dumps(payload).encode('utf-8'), headers=headers)
        with self.opener.open(req, timeout=self.timeout) as r:
            if r.headers.get('Mcp-Session-Id'):
                self.session_id = r.headers['Mcp-Session-Id']
            text = r.read().decode('utf-8')
        if not text:
            return None
        if text.startswith('event:') or text.startswith('data:'):
            data = '\n'.join(line[5:].strip() for line in text.splitlines() if line.startswith('data:'))
            response = json.loads(data)
        else:
            response = json.loads(text)
        if response.get('error'):
            raise RuntimeError(json.dumps(response['error'], ensure_ascii=False))
        return response.get('result', response)

    def initialize(self):
        result = self.request('initialize', {
            'protocolVersion': '2024-11-05', 'capabilities': {},
            'clientInfo': {'name': 'sky169938-project-local-analysis', 'version': '1.0'}
        })
        self.request('notifications/initialized', notification=True)
        return result

    def call(self, name, arguments=None):
        return self.request('tools/call', {'name': name, 'arguments': arguments or {}})

    def structured(self, result):
        meta = result.get('_meta', {}).get('ida_mcp', {})
        if meta.get('output_truncated'):
            url = meta['download_url']
            if not url.startswith('http://127.0.0.1:13337/'):
                raise RuntimeError('Refusing non-local output URL')
            with self.opener.open(url, timeout=self.timeout) as r:
                return json.load(r)
        if 'structuredContent' in result:
            return result['structuredContent']
        content = result.get('content', [])
        for item in content:
            if item.get('type') == 'text':
                try:
                    return json.loads(item['text'])
                except ValueError:
                    return {'text': item['text']}
        return result

    def save(self, label, data):
        path = W / 'logs' / ('ida_mcp_' + label + '.json')
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        return path

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('tool', nargs='?', default='server_health')
    parser.add_argument('arguments', nargs='?', default='{}')
    parser.add_argument('--save', default='')
    args = parser.parse_args()
    client = IdaMcpClient()
    init = client.initialize()
    result = client.request('tools/list') if args.tool == 'tools/list' else client.call(args.tool, json.loads(args.arguments))
    if args.save:
        client.save(args.save, result)
    print(json.dumps(client.structured(result), ensure_ascii=False, indent=2))
