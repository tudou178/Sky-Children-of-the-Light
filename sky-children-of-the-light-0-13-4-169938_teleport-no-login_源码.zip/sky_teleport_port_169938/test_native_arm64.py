﻿"""ARM64 emulation tests of the actual compiled Mod, not the game/server.
Android/JNI functions and the original game functions are explicitly stubbed.
Checks native queue semantics, ABI, build guard, resource validation and timing.
This is not a phone/runtime test and does not claim official-server access.
"""
import io
import json
import pathlib
import struct
from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE, UC_HOOK_MEM_INVALID
from unicorn.arm64_const import *

W = pathlib.Path(__file__).resolve().parent
MOD_BASE = 0x1000000
GAME_BASE = 0x4000000
STACK_BASE = 0x8000000
STUB_BASE = 0x9000000
JNI_BASE = 0xA000000
DATA_BASE = 0xB000000
GAME_OBJECT = 0xC000000
STOP = STUB_BASE + 0xFF00
REGS = [UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2, UC_ARM64_REG_X3,
        UC_ARM64_REG_X4, UC_ARM64_REG_X5, UC_ARM64_REG_X6, UC_ARM64_REG_X7]

class Harness:
    def __init__(self, mismatch=False, hook_fail=False, init_fail=False):
        self.uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
        self.uc.mem_map(MOD_BASE, 0x20000)
        self.uc.mem_map(STACK_BASE, 0x20000)
        self.uc.mem_map(STUB_BASE, 0x10000)
        self.uc.mem_map(JNI_BASE, 0x20000)
        self.uc.mem_map(DATA_BASE, 0x10000)
        self.uc.mem_map(GAME_OBJECT, 0x10000)
        self.symbols = self.load_elf(W/'build/libskyteleport.so', MOD_BASE)
        self.callbacks = {}
        self.next_stub = STUB_BASE
        self.calls = []
        self.assets = set(json.loads((W/'target_levels.json').read_text()))
        self.empty_assets = set()
        self.last_asset_name = ''
        self.bundle_ok = True
        self.level_ok = True
        self.hook_fail = hook_fail
        self.init_fail = init_fail
        self.now = 10.0
        self.last_error = 5
        self.game_symbols = self.load_game(W/'target/lib/arm64-v8a/libBootloader.so')
        if mismatch:
            self.uc.mem_write(GAME_BASE + 0x210, b'\0'*20)  # GNU build-id desc.
        self.install_import_stubs()
        self.setup_jni()
        self.uc.mem_write(STOP, bytes.fromhex('c0035fd6'))
        self.uc.hook_add(UC_HOOK_CODE, self.code)
        self.uc.hook_add(UC_HOOK_MEM_INVALID, self.invalid)
        self.configure_scene()

    def w64(self, addr, value): self.uc.mem_write(addr, struct.pack('<Q', value & 0xffffffffffffffff))
    def w32(self, addr, value): self.uc.mem_write(addr, struct.pack('<I', value & 0xffffffff))
    def r64(self, addr): return struct.unpack('<Q', self.uc.mem_read(addr,8))[0]
    def r32(self, addr): return struct.unpack('<I', self.uc.mem_read(addr,4))[0]
    def cstr(self, addr):
        if not addr: return ''
        out=bytearray()
        for off in range(4096):
            c=self.uc.mem_read(addr+off,1)[0]
            if not c: return out.decode('utf-8',errors='replace')
            out.append(c)
        raise RuntimeError('unterminated string')
    def write_string(self, addr, text): self.uc.mem_write(addr,text.encode()+b'\0')
    def sym(self,name): return MOD_BASE+self.symbols[name]

    def load_elf(self,path,base):
        blob=path.read_bytes(); elf=ELFFile(io.BytesIO(blob))
        for ph in elf.iter_segments():
            if ph['p_type']=='PT_LOAD':
                self.uc.mem_write(base+ph['p_vaddr'],blob[ph['p_offset']:ph['p_offset']+ph['p_filesz']])
        for sec in elf.iter_sections():
            if sec['sh_type']=='SHT_RELA':
                for rel in sec.iter_relocations():
                    if rel['r_info_type']==1027: self.w64(base+rel['r_offset'],base+rel['r_addend'])
        return {s.name:int(s['st_value']) for s in elf.get_section_by_name('.symtab').iter_symbols() if s['st_value']}

    def load_game(self,path):
        blob=path.read_bytes(); elf=ELFFile(io.BytesIO(blob))
        size=max(s['p_vaddr']+s['p_memsz'] for s in elf.iter_segments() if s['p_type']=='PT_LOAD')
        self.uc.mem_map(GAME_BASE,(size+4095)&~4095)
        for ph in elf.iter_segments():
            if ph['p_type']=='PT_LOAD': self.uc.mem_write(GAME_BASE+ph['p_vaddr'],blob[ph['p_offset']:ph['p_offset']+ph['p_filesz']])
        symbols={s.name:GAME_BASE+int(s['st_value']) for s in elf.get_section_by_name('.dynsym').iter_symbols() if s['st_value']}
        return symbols

    def stub(self,name,callback):
        addr=self.next_stub; self.next_stub+=0x10
        self.uc.mem_write(addr,bytes.fromhex('c0035fd6'))
        self.callbacks[addr]=(name,callback)
        return addr

    def code(self,uc,addr,size,userdata):
        if addr==STOP: uc.emu_stop(); return
        if addr in self.callbacks:
            name,callback=self.callbacks[addr]
            args=[uc.reg_read(r) for r in REGS]
            result=callback(args)
            if result is not None: uc.reg_write(UC_ARM64_REG_X0,result & 0xffffffffffffffff)
            uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_LR))

    def invalid(self,uc,access,addr,size,value,userdata):
        raise RuntimeError(f'invalid memory access {access} addr {addr:x} PC={uc.reg_read(UC_ARM64_REG_PC):x}')

    def install_import_stubs(self):
        def noop(a): return 0
        def clock(a):
            seconds=int(self.now); nanos=round((self.now-seconds)*1_000_000_000)
            self.uc.mem_write(a[1],struct.pack('<qq',seconds,nanos)); return 0
        def render_format(template, vals):
            # The native source uses only %s/%d. Preserve argument order and
            # report a formatting dependency instead of silently succeeding.
            import re
            it=iter(vals)
            def replace(match):
                v=next(it)
                if match.group(0)=='%s': return self.cstr(v)
                return str(struct.unpack('<q',struct.pack('<Q',v))[0])
            return re.sub(r'%[sd]',replace,template)
        def write_formatted(a, vals):
            out=render_format(self.cstr(a[2]),vals)
            encoded=out.encode(); raw=encoded[:max(0,a[1]-1)]
            if a[1]: self.uc.mem_write(a[0],raw+b'\0')
            return len(encoded)
        def fmt(a): return write_formatted(a,a[3:])
        def vfmt(a):
            # AArch64 va_list: stack, gr_top, vr_top, gr_offs, vr_offs.
            va=a[3]; stack=self.r64(va); top=self.r64(va+8)
            offs=struct.unpack('<i',self.uc.mem_read(va+24,4))[0]
            vals=[]
            for _ in range(8):
                if offs<0:
                    vals.append(self.r64(top+offs)); offs+=8
                else:
                    vals.append(self.r64(stack)); stack+=8
            return write_formatted(a,vals)
        def dladdr(a):
            self.w64(a[1],0); self.w64(a[1]+8,GAME_BASE); self.w64(a[1]+16,0); self.w64(a[1]+24,0); return 1
        def hook(a):
            self.calls.append(('hook',a[0],a[1]))
            if self.hook_fail: return 0
            self.w64(a[2],self.stub('original-update',self.original_update)); return DATA_BASE+0x80
        def asset_open(a):
            path=self.cstr(a[1]); self.calls.append(('asset',path))
            name=path.removeprefix('Data/Levels/').removesuffix('/Resources.lua')
            self.last_asset_name=name
            return DATA_BASE+0x100 if name in self.assets else 0
        def log(a): self.calls.append(('log',self.cstr(a[2]))); return 0
        handlers={
            'shadowhook_init':lambda a:5 if self.init_fail else 0,
            'shadowhook_set_recordable':noop,
            'shadowhook_dlopen':lambda a:DATA_BASE+0x70,
            'shadowhook_dlsym':lambda a:self.game_symbols.get(self.cstr(a[1]),0),
            'dladdr':dladdr,
            '__android_log_print':log,
            'AAssetManager_fromJava':lambda a:DATA_BASE+0x60,
            'shadowhook_hook_sym_addr':hook,
            'shadowhook_get_errno':lambda a:5,
            'pthread_mutex_lock':noop,'pthread_mutex_unlock':noop,
            'snprintf':fmt,'vsnprintf':vfmt,'clock_gettime':clock,
            'AAssetManager_open':asset_open,'AAsset_close':noop,
            'AAsset_getLength':lambda a:0 if self.last_asset_name in self.empty_assets else 1,
            '__cxa_finalize':noop,'__cxa_atexit':noop,'__register_atfork':noop,
            'getauxval':noop,'__system_property_get':noop,'strncmp':noop,
        }
        elf=ELFFile(io.BytesIO((W/'build/libskyteleport.so').read_bytes()))
        for sec in elf.iter_sections():
            if sec['sh_type']=='SHT_RELA':
                symtab=elf.get_section(sec['sh_link'])
                for rel in sec.iter_relocations():
                    if rel['r_info_type']==1026:
                        name=symtab.get_symbol(rel['r_info_sym']).name
                        self.w64(MOD_BASE+rel['r_offset'],self.stub(name,handlers[name]))
        # Never emulate the actual game. Check what args the Mod would pass.
        for n,func in [('_ZN18ResourceBundleBarn14TryAccessLevelEPKcb',self.try_access),
                       ('_ZN4Game11LevelExistsEPKc',self.exists),
                       ('_ZN14CheckpointBarn13m_ChangeLevelEP4GamePKc',self.change)]:
            self.callbacks[self.game_symbols[n]]=(n,func)

    def setup_jni(self):
        self.env=JNI_BASE; self.table=JNI_BASE+0x1000; self.w64(self.env,self.table)
        def strlen(a): return len(self.cstr(a[1]).encode())
        def getchars(a): return a[1]
        def newstring(a): self.last_string=self.cstr(a[1]); return a[1]
        jni={21:lambda a:a[1],22:lambda a:0,167:newstring,168:strlen,169:getchars,170:lambda a:0}
        for index,callback in jni.items(): self.w64(self.table+index*8,self.stub(f'JNI[{index}]',callback))

    def original_update(self,a):
        assert a[0] in (GAME_OBJECT,0)
        self.calls.append(('original',a[0])); return 0x123456789ABCDEF0
    def try_access(self,a):
        self.calls.append(('bundle',a[0],self.cstr(a[1]),a[2])); return int(self.bundle_ok)
    def exists(self,a):
        self.calls.append(('exists',a[0],self.cstr(a[1]))); return int(self.level_ok)
    def change(self,a):
        self.calls.append(('change',a[0],a[1],self.cstr(a[2]))); return 1

    def configure_scene(self,mode=3,paused=0,queued='',level='CandleSpace',
                        bundles=True,vfs=True,events=True,lua=True,manager=True,
                        init_mask=7,pending_load=0,active_load=0,jobs=0):
        self.w32(GAME_OBJECT+0x1424,mode)
        self.write_string(GAME_OBJECT+0x1428,level)
        self.write_string(GAME_OBJECT+0x1448,queued)
        self.uc.mem_write(GAME_OBJECT+0x1488,bytes([paused]))
        self.w32(GAME_OBJECT+0x160C,init_mask)
        self.w64(GAME_OBJECT+0x340,DATA_BASE+0x10 if bundles else 0)
        self.w64(GAME_OBJECT+0xD0,DATA_BASE+0x20 if vfs else 0)
        self.w64(GAME_OBJECT+0x558,DATA_BASE+0x30 if events else 0)
        self.w64(GAME_OBJECT+0x20,DATA_BASE+0x40 if lua else 0)
        self.w64(GAME_OBJECT+0x170,DATA_BASE+0x2000 if manager else 0)
        self.w64(DATA_BASE+0x2000+0x4C0,pending_load)
        self.w64(DATA_BASE+0x2000+0x4C8,active_load)
        self.w32(DATA_BASE+0x2000+0x4D8,jobs)
        # No account/local avatar is initialized in the test game object.
        # Guard these pointers to prove the Mod never dereferences them.
        self.w64(GAME_OBJECT+0x870,0xDEAD0000)
        self.w64(GAME_OBJECT+0x2E0,0xDEAD1000)
    def invoke(self,name,*args):
        for i,r in enumerate(REGS): self.uc.reg_write(r,args[i] if i<len(args) else 0)
        self.uc.reg_write(UC_ARM64_REG_SP,STACK_BASE+0x18000)
        self.uc.reg_write(UC_ARM64_REG_LR,STOP)
        self.uc.emu_start(self.sym(name),STOP+4,count=100000)
        assert self.uc.reg_read(UC_ARM64_REG_PC)==STOP,hex(self.uc.reg_read(UC_ARM64_REG_PC))
        return self.uc.reg_read(UC_ARM64_REG_X0)
    def init(self): return self.invoke('Java_sky_teleport_TeleportOverlay_nativeInit',self.env,0,DATA_BASE+0x50)
    def update(self): return self.invoke('proxy_update',GAME_OBJECT)
    def ready(self): return self.uc.mem_read(self.sym('engine_ready'),1)[0]
    def status(self):
        self.invoke('Java_sky_teleport_TeleportOverlay_nativeStatus',self.env,0)
        return self.last_string
    def request(self,name):
        self.write_string(JNI_BASE+0x10000,name)
        return self.invoke('Java_sky_teleport_TeleportOverlay_nativeRequest',self.env,0,JNI_BASE+0x10000)
    def pending(self): return self.cstr(self.sym('pending_level'))

passes=[]
def test(name,fn):
    fn(); passes.append(name); print('PASS',name,flush=True)

h=Harness()
def init_ok():
    assert h.init()==0 and h.r32(h.sym('installed'))==1
    assert len([c for c in h.calls if c[0]=='hook'])==1
    assert h.init()==0 and len([c for c in h.calls if c[0]=='hook'])==1
    assert h.ready()==0
    assert 'Java_sky_teleport_TeleportOverlay_nativeReady' not in h.symbols

test('Exact 169938 guard, single/idempotent hook; no login-gating JNI export',init_ok)

def update_ok():
    h.calls.clear(); assert h.update()==0x123456789ABCDEF0
    assert h.calls==[('original',GAME_OBJECT)] and h.ready()==1
    assert h.cstr(h.sym('current_level'))=='CandleSpace'

test('Running mode 3: original UpdateSync/result retained; no account/avatar access',update_ok)

def queue_ok():
    assert h.request('Dawn')==0 and h.pending()=='Dawn'
    assert not any(c[0]=='change' for c in h.calls)
    assert h.request('Night')==0 and h.pending()=='Night'
    h.calls.clear(); assert h.update()==0x123456789ABCDEF0
    assert [c[0] for c in h.calls][:4]==['original','bundle','exists','change']
    assert [c for c in h.calls if c[0]=='change']==[('change',0,GAME_OBJECT,'Night')]
    assert [c for c in h.calls if c[0]=='bundle'][0][-1]==0 and h.pending()==''
    assert h.request('Dawn')==4
    h.now+=2.01; assert h.request('Dawn')==0
    h.calls.clear(); h.update()
    assert [c for c in h.calls if c[0]=='change']==[('change',0,GAME_OBJECT,'Dawn')]
    h.calls.clear(); h.update()
    assert not any(c[0]=='change' for c in h.calls)

test('JNI queues latest selection; game-thread MineSky ABI; cooldown; exactly once',queue_ok)

def early_ok():
    x=Harness(); x.configure_scene(mode=0,init_mask=1,level=''); assert x.init()==0
    assert x.request('Dawn')==0 and x.pending()=='Dawn'
    x.calls.clear(); x.update(); assert x.ready()==0 and x.pending()=='Dawn'
    assert x.calls==[('original',GAME_OBJECT)]
    assert '无需登录' in x.status() and '本地' in x.status()
    assert x.request('Night')==0 and x.pending()=='Night'
    x.configure_scene(); x.calls.clear(); x.update()
    assert [c for c in x.calls if c[0]=='change']==[('change',0,GAME_OBJECT,'Night')]

test('Pre-login/startup selection accepted, replaces pending choice, executes after local init',early_ok)

def ready_mode_ok():
    x=Harness(); x.configure_scene(mode=2); assert x.init()==0
    assert x.request('Dawn')==0; x.calls.clear(); x.update()
    assert x.ready()==1 and [c for c in x.calls if c[0]=='change']==[('change',0,GAME_OBJECT,'Dawn')]

test('Ready mode 2 also works with fully initialized module groups',ready_mode_ok)

def paused_ok():
    x=Harness(); assert x.init()==0; x.configure_scene(paused=1)
    assert x.request('Night')==0; x.calls.clear(); x.update()
    assert x.ready()==1 and x.pending()=='Night'
    assert x.calls==[('original',GAME_OBJECT)] and '暂停' in x.status()
    x.configure_scene(); x.calls.clear(); x.update()
    assert [c for c in x.calls if c[0]=='change']==[('change',0,GAME_OBJECT,'Night')]

test('Dialog/focus pause accepts and preserves selection; resume executes once',paused_ok)

for title,kw in [('initializing mode 0',{'mode':0}),('loading mode 1',{'mode':1}),
                 ('unknown mode 4',{'mode':4}),('unknown mode 0xffffffff',{'mode':0xffffffff}),
                 ('queued stock transition',{'queued':'Dawn'}),('empty current level',{'level':''}),
                 ('missing bundles',{'bundles':False}),('missing VFS',{'vfs':False}),
                 ('missing EventBarn',{'events':False}),('missing Lua state',{'lua':False}),
                 ('missing ResourceManager',{'manager':False}),('only core group initialized',{'init_mask':1}),
                 ('missing gameplay group',{'init_mask':3}),('resource load queued',{'pending_load':1}),
                 ('resource load active',{'active_load':1}),('resource jobs active',{'jobs':1})]:
    def f(kw=kw):
        x=Harness(); assert x.init()==0; x.configure_scene(**kw)
        assert x.request('Dawn')==0 and x.pending()=='Dawn'
        x.calls.clear(); x.update(); assert x.ready()==0 and x.pending()=='Dawn'
        assert x.calls==[('original',GAME_OBJECT)]
        x.configure_scene(); x.calls.clear(); x.update()
        assert [c for c in x.calls if c[0]=='change']==[('change',0,GAME_OBJECT,'Dawn')]
    test('Defer, not reject selection during '+title,f)

def null_game_ok():
    x=Harness(); assert x.init()==0; assert x.request('Dawn')==0; x.calls.clear()
    assert x.invoke('proxy_update',0)==0x123456789ABCDEF0
    assert x.pending()=='Dawn' and x.calls==[('original',0)]

test('Mod adds no null game dereference after stubbed original update',null_game_ok)

def timeout_ok():
    x=Harness(); assert x.init()==0; x.configure_scene(mode=1)
    assert x.request('Dawn')==0; x.now+=60.01; x.calls.clear(); x.update()
    assert x.pending()=='' and '超时' in x.status() and x.calls==[('original',GAME_OBJECT)]
    assert x.request('Night')==0

test('Local init timeout releases queue and reports reason without forcing load',timeout_ok)

def long_pause_ok():
    x=Harness(); assert x.init()==0; x.configure_scene(paused=1)
    assert x.request('Dawn')==0; x.now+=90; x.update(); assert x.pending()=='Dawn'
    x.configure_scene(); x.calls.clear(); x.update()
    assert [c for c in x.calls if c[0]=='change']==[('change',0,GAME_OBJECT,'Dawn')]

test('Long dialog pause does not discard a valid request before resuming',long_pause_ok)

def unavailable_ok():
    x=Harness(); assert x.init()==0; x.bundle_ok=False; assert x.request('Dawn')==0
    x.calls.clear(); x.update()
    assert any(c[0]=='bundle' for c in x.calls)
    assert not any(c[0] in ['exists','change'] for c in x.calls)
    assert '资源尚未就绪' in x.status() and x.pending()==''

test('Unavailable bundle rejected before assertion-prone LevelExists; status explains',unavailable_ok)

def missing_ok():
    x=Harness(); assert x.init()==0; x.level_ok=False; assert x.request('Dawn')==0
    x.calls.clear(); x.update()
    assert any(c[0]=='exists' for c in x.calls) and not any(c[0]=='change' for c in x.calls)
    assert '没有该地图' in x.status()

test('Missing game level rejected without any forced change',missing_ok)

for value in ['../Dawn','Dawn/Resources.lua','晨岛','A'*32,'']:
    def invalid_name_ok(value=value):
        assert h.request(value)==3
    test('JNI rejects unsafe/invalid map name '+repr(value),invalid_name_ok)
def no_asset_ok(): assert h.request('DefinitelyNotALevel')==3
test('JNI rejects nonexistent APK map',no_asset_ok)
def empty_asset_ok():
    h.empty_assets.add('Dawn'); assert h.request('Dawn')==3; h.empty_assets.clear()
test('JNI rejects empty Resources.lua as does the dynamic Java map list',empty_asset_ok)
def null_name_ok():
    assert h.invoke('Java_sky_teleport_TeleportOverlay_nativeRequest',h.env,0,0)==3
test('JNI rejects null map name',null_name_ok)

def all_maps_ok():
    x=Harness(); assert x.init()==0
    for name in sorted(x.assets):
        assert x.request(name)==0; x.calls.clear(); x.update()
        assert [c for c in x.calls if c[0]=='change']==[('change',0,GAME_OBJECT,name)]
        assert '无需登录' in x.status(); x.now+=2.01

test('All 51 installed-APK map names pass validation/ABI with explicit resource stubs',all_maps_ok)

def bad_build_ok():
    x=Harness(mismatch=True); assert x.init()==4 and x.r32(x.sym('installed'))==0
    assert not any(c[0]=='hook' for c in x.calls) and x.request('Dawn')==1

test('Wrong build ID fails closed; no hook or queued request',bad_build_ok)
def bad_header_ok():
    x=Harness(); x.uc.mem_write(x.game_symbols['_ZN4Game10UpdateSyncEv'],b'\0'*16)
    assert x.init()==4 and not any(c[0]=='hook' for c in x.calls)
test('Wrong target prologue fails closed before hook',bad_header_ok)
def bad_rva_ok():
    x=Harness(); x.game_symbols['_ZN14CheckpointBarn13m_ChangeLevelEP4GamePKc']+=4
    assert x.init()==4 and not any(c[0]=='hook' for c in x.calls)
test('Wrong change-level RVA fails closed',bad_rva_ok)
def bad_hook_ok():
    x=Harness(hook_fail=True); assert x.init()==6 and x.r32(x.sym('installed'))==0
    assert x.ready()==0 and x.request('Dawn')==1
test('Hook failure keeps Mod disabled',bad_hook_ok)
def bad_init_ok():
    x=Harness(init_fail=True); assert x.init()==2 and not any(c[0]=='hook' for c in x.calls)
test('Hook-engine init failure keeps Mod disabled',bad_init_ok)
def java_no_gate_ok():
    text=(W/'mod/java/sky/teleport/TeleportOverlay.java').read_text(encoding='utf-8')
    assert 'nativeReady' not in text and '请先完成原版登录' not in text
    assert 'nativeRequest(name)' in text and 'Data/Levels' in text
    assert 'LoginSync(' not in (W/'mod/native/skyteleport.c').read_text(encoding='utf-8')
test('Java submits title/login-screen choices; no login-sync or native-ready UI gate',java_no_gate_ok)

import hashlib
report={'test_type':'Actual ARM64 libskyteleport.so emulation plus one Java-source check; Android/JNI/original-game calls explicitly stubbed',
        'tests_passed':len(passes),'native_emulation_cases':len(passes)-1,'java_source_checks':1,
        'original_game_functions_executed':False,
        'tests':passes,'apk_levels_checked':len(h.assets),
        'mod_sha256':hashlib.sha256((W/'build/libskyteleport.so').read_bytes()).hexdigest(),
        'account_or_avatar_required_by_mod':False,'device_runtime_tested':False}
(W/'native_tests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('TOTAL',len(passes),'PASS; not a device/runtime test',flush=True)
