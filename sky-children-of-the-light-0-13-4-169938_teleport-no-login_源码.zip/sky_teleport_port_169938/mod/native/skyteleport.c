/* Map teleport port for Sky 0.13.4 (169938), with no login requirement.
 * Preserves MineSky's CheckpointBarn::m_ChangeLevel behavior, with a
 * target-build guard and a game-thread queue. No server/login/SSL hooks.
 * Selection is accepted before the local engine is ready; execution waits
 * for initialized resources, not AccountBarn::IsReady or authentication.
 * The only hooked game function is Game::UpdateSync; its original result
 * and execution are preserved. shadowhook is the original MIT dependency.
 */
#define _GNU_SOURCE
#include <jni.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <elf.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>
#include "shadowhook.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "SkyTeleport", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "SkyTeleport", __VA_ARGS__)

/* Verified against the unmodified 169938 libBootloader.so via IDA MCP.
 * See IDA_MCP_REVIEW.md and IDA_NO_LOGIN_REVIEW.md for ABI/field evidence.
 * GameMode 2 is Ready, 3 is Running; neither is an account/login state.
 * Game::UpdateSync changes Ready to Running after full initialization. */
#define GAME_MODE_OFFSET 0x1424u
#define GAME_MODE_READY 2u
#define GAME_MODE_RUNNING 3u
#define GAME_LEVEL_OFFSET 0x1428u
#define GAME_QUEUED_LEVEL_OFFSET 0x1448u
#define GAME_PAUSED_OFFSET 0x1488u
#define GAME_INIT_MASK_OFFSET 0x160Cu /* Initialized module groups, all 1|2|4. */
#define GAME_LUA_OFFSET 0x20u
#define GAME_RESOURCES_OFFSET 0x170u
#define GAME_BUNDLES_OFFSET 0x340u
#define GAME_VFS_OFFSET 0xD0u /* Vfs* passed to ResourceManager::FileExists. */
#define GAME_EVENTS_OFFSET 0x558u /* EventBarn* used by m_ChangeLevel. */
#define RESOURCE_PENDING_OFFSET 0x4C0u
#define RESOURCE_LOADING_OFFSET 0x4C8u
#define RESOURCE_JOBS_OFFSET 0x4D8u

static const uint8_t EXPECTED_BUILD_ID[20] = {
    0x81,0x69,0x46,0x41,0x35,0x56,0xC9,0xB2,0xE6,0xB4,
    0x0B,0x55,0x2B,0x98,0x2E,0x3F,0xF0,0x53,0xF8,0x6C
};
static const uint8_t EXPECTED_UPDATE_HEAD[16] = {
    0xE9,0x23,0xBB,0x6D,0xFC,0x5F,0x01,0xA9,
    0xF6,0x57,0x02,0xA9,0xF4,0x4F,0x03,0xA9
};

typedef uint64_t (*UpdateSyncFn)(void *game);
typedef void *(*ChangeLevelFn)(void *checkpoint, void *game, const char *level);
typedef bool (*TryAccessLevelFn)(void *bundles, const char *level, bool request);
typedef uint64_t (*LevelExistsFn)(void *game, const char *level);

static UpdateSyncFn original_update;
static ChangeLevelFn change_level;
static TryAccessLevelFn try_access_level;
static LevelExistsFn level_exists;
static void *game_handle;
static void *hook_stub;
static jobject asset_reference;
static AAssetManager *asset_manager;
static atomic_int installed = ATOMIC_VAR_INIT(0);
static pthread_mutex_t state_mutex = PTHREAD_MUTEX_INITIALIZER;
static char pending_level[32];
static char current_level[32];
static char status_message[256] = "等待游戏启动；无需先登录";
static bool engine_ready;
static bool engine_paused;
static uint64_t next_request_ms;
static uint64_t pending_since_ms;
#define REQUEST_TIMEOUT_MS 60000u

static uint64_t now_ms(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint64_t)t.tv_sec * 1000u + (uint64_t)t.tv_nsec / 1000000u;
}

static void set_message(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    pthread_mutex_lock(&state_mutex);
    vsnprintf(status_message, sizeof(status_message), fmt, ap);
    pthread_mutex_unlock(&state_mutex);
    va_end(ap);
}

static bool build_id_matches(uintptr_t base) {
    const Elf64_Ehdr *eh = (const Elf64_Ehdr *)base;
    if (memcmp(eh->e_ident, ELFMAG, SELFMAG) != 0 || eh->e_machine != EM_AARCH64)
        return false;
    const Elf64_Phdr *ph = (const Elf64_Phdr *)(base + eh->e_phoff);
    for (unsigned i = 0; i < eh->e_phnum; ++i) {
        if (ph[i].p_type != PT_NOTE || ph[i].p_memsz > 8192u) continue;
        const uint8_t *p = (const uint8_t *)(base + ph[i].p_vaddr);
        const uint8_t *end = p + ph[i].p_memsz;
        while (p + sizeof(Elf64_Nhdr) <= end) {
            const Elf64_Nhdr *n = (const Elf64_Nhdr *)p;
            uint64_t name_size = ((uint64_t)n->n_namesz + 3u) & ~3u;
            uint64_t desc_size = ((uint64_t)n->n_descsz + 3u) & ~3u;
            if (name_size + desc_size > (uint64_t)(end - p - sizeof(*n))) break;
            const uint8_t *name = p + sizeof(*n);
            const uint8_t *desc = name + name_size;
            if (n->n_type == NT_GNU_BUILD_ID && n->n_namesz == 4u &&
                n->n_descsz == sizeof(EXPECTED_BUILD_ID) &&
                memcmp(name, "GNU", 4) == 0)
                return memcmp(desc, EXPECTED_BUILD_ID, sizeof(EXPECTED_BUILD_ID)) == 0;
            p = desc + desc_size;
        }
    }
    return false;
}

static bool local_scene_ready(const uint8_t *g) {
    if (!g) return false;
    uint32_t mode = *(const uint32_t *)(g + GAME_MODE_OFFSET);
    uint32_t initialized = *(const uint32_t *)(g + GAME_INIT_MASK_OFFSET);
    const uint8_t *resources = *(const uint8_t *const *)(g + GAME_RESOURCES_OFFSET);
    /* Do not confuse GameMode with AccountBarn::IsReady. Login, server
     * readiness, local-avatar existence and pressed-start are NOT tested. */
    return (mode == GAME_MODE_READY || mode == GAME_MODE_RUNNING) &&
           (initialized & 7u) == 7u && g[GAME_LEVEL_OFFSET] != 0 &&
           g[GAME_QUEUED_LEVEL_OFFSET] == 0 &&
           *(void *const *)(g + GAME_LUA_OFFSET) != NULL &&
           *(void *const *)(g + GAME_BUNDLES_OFFSET) != NULL &&
           *(void *const *)(g + GAME_VFS_OFFSET) != NULL &&
           *(void *const *)(g + GAME_EVENTS_OFFSET) != NULL &&
           resources != NULL &&
           *(const uint64_t *)(resources + RESOURCE_PENDING_OFFSET) == 0 &&
           *(const uint64_t *)(resources + RESOURCE_LOADING_OFFSET) == 0 &&
           *(const uint32_t *)(resources + RESOURCE_JOBS_OFFSET) == 0;
}

static uint64_t proxy_update(void *game) {
    /* All original gameplay and networking logic runs first and unchanged. */
    uint64_t result = original_update(game);
    const uint8_t *g = (const uint8_t *)game;
    bool scene_ready = local_scene_ready(g);
    bool paused = g && g[GAME_PAUSED_OFFSET] != 0;
    /* A native dialog may temporarily pause the game. Selection is allowed
     * before scene readiness and during pause; execution stays on this thread. */
    bool can_process = scene_ready && !paused;
    char request[32] = {0};
    uint64_t tick = now_ms();
    pthread_mutex_lock(&state_mutex);
    engine_ready = scene_ready;
    engine_paused = paused;
    if (g) memcpy(current_level, g + GAME_LEVEL_OFFSET, 31);
    else current_level[0] = 0;
    current_level[31] = 0;
    if (pending_level[0] != 0) {
        if (can_process) {
            memcpy(request, pending_level, sizeof(request));
            pending_level[0] = 0;
            next_request_ms = tick + 2000u;
        } else if (!paused && tick - pending_since_ms >= REQUEST_TIMEOUT_MS) {
            snprintf(status_message, sizeof(status_message),
                "本地引擎等待超时，请重新选图：%s", pending_level);
            pending_level[0] = 0;
        } else {
            snprintf(status_message, sizeof(status_message), paused ?
                "已选 %s；关闭面板/恢复游戏后传送（无需登录）" :
                "已选 %s；等待本地引擎/资源初始化（无需登录）", pending_level);
        }
    }
    pthread_mutex_unlock(&state_mutex);
    if (request[0] != 0) {
        void *bundles = *(void *const *)(g + GAME_BUNDLES_OFFSET);
        /* Never call assertion-prone LevelExists for unavailable bundles.
         * This check is about local resources, not account/server permission. */
        if (!try_access_level(bundles, request, false)) {
            set_message("地图资源尚未就绪：%s", request);
            LOGI("Rejected unavailable level bundle: %s", request);
        } else if ((level_exists(game, request) & 1u) == 0) {
            set_message("游戏中没有该地图：%s", request);
        } else {
            /* Same call ABI as MineSky/CheckpointBarn.cpp; 'this' is unused.
             * Stock fade -> QueueLevel -> Game::Update/LevelLoad, no forced load. */
            change_level(NULL, game, request);
            set_message("已提交原版换图事件：%s（无需登录）", request);
            LOGI("Queued stock CheckpointBarn level change without login gate: %s", request);
        }
    }
    return result;
}

JNIEXPORT jint JNICALL
Java_sky_teleport_TeleportOverlay_nativeInit(JNIEnv *env, jclass cls, jobject assets) {
    (void)cls;
    int expected = 0;
    if (!atomic_compare_exchange_strong(&installed, &expected, -1))
        return expected == 1 ? 0 : 1;
    int err = shadowhook_init(SHADOWHOOK_MODE_UNIQUE, false);
    if (err != SHADOWHOOK_ERRNO_OK) {
        set_message("Hook 初始化失败：%d", err);
        atomic_store(&installed, 0);
        return 2;
    }
    shadowhook_set_recordable(false);
    game_handle = shadowhook_dlopen("libBootloader.so");
    void *update = game_handle ? shadowhook_dlsym(game_handle, "_ZN4Game10UpdateSyncEv") : NULL;
    change_level = game_handle ? (ChangeLevelFn)shadowhook_dlsym(game_handle,
        "_ZN14CheckpointBarn13m_ChangeLevelEP4GamePKc") : NULL;
    try_access_level = game_handle ? (TryAccessLevelFn)shadowhook_dlsym(game_handle,
        "_ZN18ResourceBundleBarn14TryAccessLevelEPKcb") : NULL;
    level_exists = game_handle ? (LevelExistsFn)shadowhook_dlsym(game_handle,
        "_ZN4Game11LevelExistsEPKc") : NULL;
    Dl_info info;
    if (!update || !change_level || !try_access_level || !level_exists ||
        dladdr(update, &info) == 0) {
        set_message("找不到目标游戏的换图函数");
        atomic_store(&installed, 0);
        return 3;
    }
    uintptr_t base = (uintptr_t)info.dli_fbase;
    if (!build_id_matches(base) || (uintptr_t)update - base != 0xA99C24u ||
        (uintptr_t)change_level - base != 0x98A5DCu ||
        (uintptr_t)try_access_level - base != 0xBDF04Cu ||
        (uintptr_t)level_exists - base != 0xA9AC90u ||
        memcmp(update, EXPECTED_UPDATE_HEAD, sizeof(EXPECTED_UPDATE_HEAD)) != 0) {
        set_message("构建不匹配；仅支持原版 169938，未应用任何修改");
        LOGE("Build guard failed; no hook installed");
        atomic_store(&installed, 0);
        return 4;
    }
    asset_reference = assets ? (*env)->NewGlobalRef(env, assets) : NULL;
    asset_manager = asset_reference ? AAssetManager_fromJava(env, asset_reference) : NULL;
    if (!asset_reference || !asset_manager) {
        if (asset_reference) (*env)->DeleteGlobalRef(env, asset_reference);
        asset_reference = NULL;
        set_message("无法读取 APK 地图资源");
        atomic_store(&installed, 0);
        return 5;
    }
    hook_stub = shadowhook_hook_sym_addr(update, (void *)proxy_update, (void **)&original_update);
    if (!hook_stub || !original_update) {
        int hook_error = shadowhook_get_errno();
        set_message("传送 Hook 安装失败：%d", hook_error);
        LOGE("Update hook failed: %d", hook_error);
        (*env)->DeleteGlobalRef(env, asset_reference);
        asset_reference = NULL;
        asset_manager = NULL;
        atomic_store(&installed, 0);
        return 6;
    }
    set_message("地图传送已加载；可直接选图，无需先登录");
    atomic_store_explicit(&installed, 1, memory_order_release);
    LOGI("Map-only port loaded for 169938; no login gate, no server/account/TLS hooks");
    return 0;
}

JNIEXPORT jint JNICALL
Java_sky_teleport_TeleportOverlay_nativeRequest(JNIEnv *env, jclass cls, jstring level) {
    (void)cls;
    if (atomic_load_explicit(&installed, memory_order_acquire) != 1) return 1;
    /* Do not reject an early/unsigned-in selection. Only native installation
     * and the APK map name/resources are needed to put it in the queue. */
    if (level == NULL) return 3;
    jsize len = (*env)->GetStringUTFLength(env, level);
    if (len < 1 || len > 31) return 3;
    const char *name = (*env)->GetStringUTFChars(env, level, NULL);
    if (!name) return 3;
    char validated[32] = {0};
    bool valid = true;
    for (int i = 0; i < len; ++i) {
        unsigned char c = (unsigned char)name[i];
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '_')) { valid = false; break; }
        validated[i] = (char)c;
    }
    (*env)->ReleaseStringUTFChars(env, level, name);
    if (!valid) return 3;
    char path[96];
    snprintf(path, sizeof(path), "Data/Levels/%s/Resources.lua", validated);
    AAsset *asset = AAssetManager_open(asset_manager, path, AASSET_MODE_UNKNOWN);
    if (!asset) return 3;
    bool nonempty = AAsset_getLength(asset) > 0;
    AAsset_close(asset);
    if (!nonempty) return 3;
    uint64_t tick = now_ms();
    pthread_mutex_lock(&state_mutex);
    if (tick < next_request_ms) {
        pthread_mutex_unlock(&state_mutex);
        return 4;
    }
    /* Last selection wins while waiting for initialization/focus, so an early
     * choice cannot permanently lock the map UI behind another request. */
    memcpy(pending_level, validated, sizeof(pending_level));
    pending_since_ms = tick;
    snprintf(status_message, sizeof(status_message),
        "已选择：%s；等待游戏线程处理（无需登录）", validated);
    pthread_mutex_unlock(&state_mutex);
    return 0;
}

JNIEXPORT jstring JNICALL
Java_sky_teleport_TeleportOverlay_nativeStatus(JNIEnv *env, jclass cls) {
    (void)cls;
    char text[384];
    pthread_mutex_lock(&state_mutex);
    const char *state = engine_paused ? "（暂停/面板打开）" :
                        engine_ready ? "" : "（本地资源初始化中）";
    if (current_level[0])
        snprintf(text, sizeof(text), "当前地图：%s%s\n%s", current_level,
            state, status_message);
    else snprintf(text, sizeof(text), "%s", status_message);
    pthread_mutex_unlock(&state_mutex);
    return (*env)->NewStringUTF(env, text);
}
