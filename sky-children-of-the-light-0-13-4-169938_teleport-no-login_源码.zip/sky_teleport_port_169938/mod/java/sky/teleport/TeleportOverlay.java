package sky.teleport;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;
import java.util.Map;
import java.util.WeakHashMap;

/** Native Android UI for the map-only MineSky port. Needs no floating-window
 *  permission, no new resources, no web/network access, and no private launcher. */
public final class TeleportOverlay {
    private static final Map<Activity, TeleportOverlay> INSTANCES = new WeakHashMap<>();
    private static boolean loadAttempted;
    private static boolean nativeLoaded;
    private static String loadError = "";
    private final Activity activity;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<String> allLevels = new ArrayList<>();
    private final ArrayList<String> filteredLevels = new ArrayList<>();
    private final Button floating;
    private final FrameLayout container;
    private AlertDialog dialog;
    private TextView status;
    private ArrayAdapter<String> adapter;
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            if (dialog != null && dialog.isShowing() && !activity.isFinishing()) {
                if (status != null) status.setText(getStatus());
                handler.postDelayed(this, 600);
            }
        }
    };

    private static native int nativeInit(AssetManager assets);
    private static native int nativeRequest(String name);
    private static native String nativeStatus();

    public static void attach(Activity activity) {
        if (INSTANCES.containsKey(activity) || activity.isFinishing()) return;
        TeleportOverlay ui = new TeleportOverlay(activity);
        INSTANCES.put(activity, ui);
    }

    public static void detach(Activity activity) {
        TeleportOverlay ui = INSTANCES.remove(activity);
        if (ui == null) return;
        ui.handler.removeCallbacks(ui.refresh);
        if (ui.dialog != null) ui.dialog.dismiss();
        ViewGroup parent = (ViewGroup)ui.container.getParent();
        if (parent != null) parent.removeView(ui.container);
    }

    private TeleportOverlay(Activity activity) {
        this.activity = activity;
        ensureLoaded();
        readLevels();
        container = new FrameLayout(activity);
        container.setClickable(false);
        container.setFocusable(false);
        floating = new Button(activity);
        floating.setText("传送");
        floating.setTextColor(Color.WHITE);
        floating.setTextSize(15);
        floating.setAllCaps(false);
        floating.setMinWidth(0);
        floating.setMinHeight(0);
        floating.setMinimumWidth(0);
        floating.setMinimumHeight(0);
        floating.setPadding(dp(14), dp(5), dp(14), dp(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xB5223E55);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), 0xAAE0F3FF);
        floating.setBackground(bg);
        floating.setElevation(dp(8));
        floating.setContentDescription("地图传送，按住可拖动按钮");
        FrameLayout.LayoutParams buttonParams = new FrameLayout.LayoutParams(dp(70), dp(40));
        buttonParams.gravity = Gravity.TOP | Gravity.LEFT;
        buttonParams.leftMargin = dp(12);
        buttonParams.topMargin = dp(90);
        container.addView(floating, buttonParams);
        activity.addContentView(container, new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        floating.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openPanel(); }
        });
        floating.setOnTouchListener(new View.OnTouchListener() {
            private float startX, startY, viewX, viewY;
            private boolean dragged;
            @Override public boolean onTouch(View view, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getRawX(); startY = event.getRawY();
                        viewX = view.getX(); viewY = view.getY(); dragged = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - startX, dy = event.getRawY() - startY;
                        if (Math.abs(dx) + Math.abs(dy) > dp(7)) dragged = true;
                        if (dragged) {
                            view.setX(Math.max(0, Math.min(container.getWidth() - view.getWidth(), viewX + dx)));
                            view.setY(Math.max(0, Math.min(container.getHeight() - view.getHeight(), viewY + dy)));
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!dragged) view.performClick();
                        return true;
                    case MotionEvent.ACTION_CANCEL: return true;
                    default: return false;
                }
            }
        });
    }

    private void ensureLoaded() {
        if (loadAttempted) return;
        loadAttempted = true;
        try {
            System.loadLibrary("shadowhook");
            System.loadLibrary("skyteleport");
            int result = nativeInit(activity.getAssets());
            nativeLoaded = result == 0;
            if (!nativeLoaded) loadError = nativeStatus();
        } catch (Throwable error) {
            loadError = "传送 Mod 加载失败：" + error.getClass().getSimpleName();
            Log.e("SkyTeleport", "Native load failed", error);
        }
    }

    private void readLevels() {
        try {
            String[] names = activity.getAssets().list("Data/Levels");
            if (names == null) return;
            Arrays.sort(names, new Comparator<String>() {
                @Override public int compare(String a, String b) {
                    return label(a).compareToIgnoreCase(label(b));
                }
            });
            for (String name : names) {
                if (!name.matches("[A-Za-z0-9_]{1,31}")) continue;
                try (java.io.InputStream stream = activity.getAssets().open(
                        "Data/Levels/" + name + "/Resources.lua")) {
                    if (stream.read() != -1) allLevels.add(name);
                } catch (IOException ignored) { }
            }
        } catch (IOException error) { Log.e("SkyTeleport", "Map list failed", error); }
    }

    private void openPanel() {
        if (dialog != null && dialog.isShowing()) return;
        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(6), dp(16), dp(4));
        status = new TextView(activity);
        status.setTextSize(12);
        status.setText(getStatus());
        panel.addView(status, new LinearLayout.LayoutParams(-1, -2));
        EditText search = new EditText(activity);
        search.setSingleLine(true);
        search.setTextSize(14);
        search.setHint("搜索地图中文名 / 英文名");
        panel.addView(search, new LinearLayout.LayoutParams(-1, -2));
        ListView list = new ListView(activity);
        adapter = new ArrayAdapter<String>(activity, android.R.layout.simple_list_item_1,
                                           new ArrayList<String>());
        list.setAdapter(adapter);
        int h = Math.max(dp(130), Math.min(dp(320), activity.getResources().getDisplayMetrics().heightPixels - dp(200)));
        panel.addView(list, new LinearLayout.LayoutParams(-1, h));
        TextView hint = new TextView(activity);
        hint.setTextSize(11);
        hint.setText("无需先登录，点击地图即可提交传送。\n本地资源初始化完毕后执行；不提供联网账号或存档同步。");
        panel.addView(hint, new LinearLayout.LayoutParams(-1, -2));
        updateFilter("");
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateFilter(s.toString());
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        list.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> parent, View v, int pos, long id) {
                if (pos >= 0 && pos < filteredLevels.size()) request(filteredLevels.get(pos));
            }
        });
        dialog = new AlertDialog.Builder(activity)
            .setTitle("地图传送 · 169938 · 免登录")
            .setView(panel)
            .setNegativeButton("关闭", null)
            .create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface d) { handler.removeCallbacks(refresh); }
        });
        dialog.show();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        handler.post(refresh);
    }

    private void updateFilter(String query) {
        String q = query.trim().toLowerCase(Locale.ROOT);
        filteredLevels.clear();
        ArrayList<String> labels = new ArrayList<>();
        for (String name : allLevels) {
            String text = label(name);
            if (q.isEmpty() || text.toLowerCase(Locale.ROOT).contains(q)) {
                filteredLevels.add(name); labels.add(text);
            }
        }
        if (adapter != null) {
            adapter.clear(); adapter.addAll(labels); adapter.notifyDataSetChanged();
        }
    }

    private void request(String name) {
        if (!nativeLoaded) { toast(loadError); return; }
        // Always submit the selection, including at the title/login screen.
        // Only the game thread waits for local initialization; no login check.
        int result = nativeRequest(name);
        switch (result) {
            case 0:
                toast("已选择：" + label(name) + "；无需先登录");
                if (dialog != null) dialog.dismiss();
                break;
            case 3: toast("目标 APK 中没有该地图资源"); break;
            case 4: toast("换图冷却中，请稍等两秒再选"); break;
            default: toast("传送 Mod 尚未成功加载"); break;
        }
    }

    private String getStatus() {
        if (!nativeLoaded) return loadError.isEmpty() ? "等待加载 Mod" : loadError;
        try { return nativeStatus(); }
        catch (Throwable error) { return "无法读取传送状态"; }
    }
    private int dp(int n) { return Math.round(n * activity.getResources().getDisplayMetrics().density); }
    private void toast(String text) { Toast.makeText(activity, text, Toast.LENGTH_LONG).show(); }

    private static String label(String n) {
        String title;
        switch (n) {
            case "CandleSpace": title = "遇境"; break;
            case "CandleSpaceEnd": title = "结尾遇境"; break;
            case "Dawn": title = "晨岛"; break;
            case "DawnCave": title = "预言山谷"; break;
            case "Dawn_TrialsWater": title = "水之试炼"; break;
            case "Dawn_TrialsEarth": title = "土之试炼"; break;
            case "Dawn_TrialsAir": title = "风之试炼"; break;
            case "Dawn_TrialsFire": title = "火之试炼"; break;
            case "Prairie_ButterflyFields": title = "云野蝴蝶平原"; break;
            case "Prairie_Cave": title = "云野幽光山洞"; break;
            case "Prairie_NestAndKeeper": title = "云野浮岛"; break;
            case "Prairie_Village": title = "云野三塔"; break;
            case "Prairie_Island": title = "圣岛"; break;
            case "DayEnd": title = "云野神庙"; break;
            case "DayHubCave": title = "云野八人门"; break;
            case "Rain": title = "雨林入口"; break;
            case "RainMid": title = "雨林荧光森林"; break;
            case "RainForest": title = "雨林密林"; break;
            case "RainShelter": title = "雨林晴天图"; break;
            case "Rain_Cave": title = "雨林地下洞穴"; break;
            case "Rain_BaseCamp": title = "大树屋"; break;
            case "RainEnd": title = "雨林神庙"; break;
            case "Sunset": title = "霞谷滑冰场"; break;
            case "SunsetRace": title = "霞谷滑行赛道"; break;
            case "Sunset_FlyRace": title = "霞谷飞行赛道"; break;
            case "Sunset_Citadel": title = "霞光城"; break;
            case "SunsetColosseum": title = "霞谷竞技场"; break;
            case "SunsetEnd": title = "霞谷神庙"; break;
            case "SunsetEnd2": title = "霞谷终点"; break;
            case "SunsetVillage": title = "圆梦村"; break;
            case "Sunset_YetiPark": title = "隐士山谷"; break;
            case "DuskStart": title = "暮土入口"; break;
            case "Dusk": title = "暮土边陲荒漠"; break;
            case "DuskMid": title = "暮土一龙图"; break;
            case "DuskGraveyard": title = "暮土四龙图"; break;
            case "Dusk_CrabField": title = "暮土沉船"; break;
            case "DuskEnd": title = "暮土神庙"; break;
            case "DuskOasis": title = "遗忘方舟"; break;
            case "Night": title = "禁阁"; break;
            case "Night2": title = "禁阁上层"; break;
            case "NightEnd": title = "禁阁终点"; break;
            case "NightArchive": title = "禁阁档案馆"; break;
            case "StormStart": title = "伊甸入口"; break;
            case "Storm": title = "暴风眼"; break;
            case "StormEnd": title = "伊甸献祭"; break;
            case "OrbitMid": title = "重生之路"; break;
            case "OrbitEnd": title = "重生终点"; break;
            case "TGCOffice": title = "办公室"; break;
            case "Nintendo_CandleSpace": title = "Nintendo 特殊区域"; break;
            case "Credits": title = "制作名单"; break;
            case "WorldEmpty": title = "空白世界"; break;
            default: title = n;
        }
        return title.equals(n) ? n : title + "  [" + n + "]";
    }
}
