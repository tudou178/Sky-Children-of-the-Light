package sky.teleport;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;

/** Retains every original TGCApplication startup action and adds only a
 *  lifecycle listener for the in-game map button. No launcher or server config. */
public final class TeleportApplication extends com.tgc.sky.TGCApplication {
    @Override public void onCreate() {
        super.onCreate();
        try {
            registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                @Override public void onActivityCreated(Activity activity, Bundle state) { }
                @Override public void onActivityStarted(Activity activity) { }
                @Override public void onActivityResumed(Activity activity) {
                    if ("com.tgc.sky.GameActivity".equals(activity.getClass().getName())) {
                        try { TeleportOverlay.attach(activity); }
                        catch (Throwable error) { Log.e("SkyTeleport", "Overlay failed", error); }
                    }
                }
                @Override public void onActivityPaused(Activity activity) { }
                @Override public void onActivityStopped(Activity activity) { }
                @Override public void onActivitySaveInstanceState(Activity activity, Bundle state) { }
                @Override public void onActivityDestroyed(Activity activity) {
                    if ("com.tgc.sky.GameActivity".equals(activity.getClass().getName()))
                        TeleportOverlay.detach(activity);
                }
            });
        } catch (Throwable error) {
            // An optional Mod UI failure must not prevent normal game startup.
            Log.e("SkyTeleport", "Lifecycle registration failed", error);
        }
    }
}
