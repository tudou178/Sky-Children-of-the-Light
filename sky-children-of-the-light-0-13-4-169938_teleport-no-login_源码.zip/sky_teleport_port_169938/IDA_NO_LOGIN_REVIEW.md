# Sky 169938：无登录门槛地图传送复核

更新：2026-11-07。延续上一会话已经生成的 `teleport-no-login.apk`，补齐说明、复核报告和源码交付。本轮未更改游戏功能代码，未重新签名或覆盖 APK；只更正了测试报告的分类描述。

## 结论和不能保证的部分

- **Mod 的登录门槛已经移除。** Java 在标题/登录界面也可调用 `nativeRequest`；原生提交只检查 Mod 是否成功加载、地图名/安装包资源和冷却，不检查账号登录状态。
- 引擎就绪后，Mod 在原 `Game::UpdateSync` 返回后的同一线程调用 `CheckpointBarn::m_ChangeLevel(nullptr, game, level)`，与所提供 MineSky 源码的调用 ABI 一致。
- 仍保留本地初始化、暂停、资源加载、原版切图和地图存在性检查。**无登录门槛不等于能在未初始化的进程中强制加载地图。** 长时间未就绪会报告超时，而非伪造账号或硬写 GameMode。
- **尚未实测真机未登录的实际换图、登录界面退出、角色生成或操控。** 本轮的模拟测试没有执行完整原版引擎、地图资源加载或服务器。
- 没有加入游戏服务器、登录同步脚本、服务器地址替换、账号/会话伪造或 TLS 绕过。原版联网和登录界面逻辑仍执行，可能影响实际使用。

## 成品与历史版本

最新 APK：`E:\sky-children-of-the-light-0-13-4-169938_teleport-no-login.apk`

- 大小：1,145,405,737 字节。
- SHA-256：`9bac052a2730753bd7147758a8973522e4abc59e5a0be1651120370028a69854`。
- 新增原生库 SHA-256：`0331cfb5de8490604022dd5a741617cd0d83fadd4d98c188647b41ca78b4a30a`。
- 新增 DEX SHA-256：`5a58c33ebb68e8ff581bd42adcc546687b00f143a7a57ca02ccddc79f81bc954`。
- 原版游戏库 SHA-256：`1204518c2d3f305e8d66e4dbb6b8514402fdd70256dcacb8797bffd9a9a758c0`。
- 原版 GNU Build ID：`816946413556c9b2e6b40b552b982e3ff053f86c`。

旧 `teleport-only.apk` 保留，其 SHA-256 为 `ff1dc3dec3ff21e31f7bc588e8233f1eb8ca96d886d88cc4ff9edfdb9630227f`。旧版只允许 mode=2，并在 UI 要求先登录，不能当作本版。

## IDA / MCP 会话

- IDA 9.3，当前本项目 PID：20952；未停止或重启其他 IDA 实例。
- 仅回环监听：`http://127.0.0.1:13337/mcp`。
- IDB：`build/ida/sky169938.i64`；输入：`target/lib/arm64-v8a/libBootloader.so`；imagebase=0。
- health 返回自动分析和 Hex-Rays 均已就绪。已保存数据库，保持后台运行。
- 本轮已有管理员权限，未再请求提权。备用 `Start-IdaMcp.ps1` 在未提权时使用正常 UAC，不绕过权限检查。
- 兼容 MCP 来源为项目内固定提交 `c133c3853faa111a9b00ee615c013b720d0c4acd`，详见 `logs/ida_mcp_source.json`。未替换全局 MCP 配置。
- `visit_patched_bytes` 统计为 **0**；类型、注释和 MCP 分析记录不等于修改游戏字节。

本轮原始证据：`logs/ida_mcp_resume_20261107_*.json`；整理证据：`logs/resume_20261107_ida_evidence.json`。

## 关键函数复核

| 函数 | RVA | 证据与作用 |
|---|---|---|
| `Game::Initialize` | `0xA98394` | 初始化 Lua/VFS/资源模块；设置初始化组掩码，不能当作账号认证。 |
| `Game::UpdateSync` | `0xA99C24` | 唯一 Hook；原函数先执行。Ready/Running 状态、启动地图和资源加载分支已复核。 |
| `CheckpointBarn::m_ChangeLevel` | `0x98A5DC` | x0=this 未读取，x1=Game，x2=level；创建 EventBarn 的原版事件，复制地图名。 |
| `ChangeLevelWithFade::OnStart` | `0x983388` | 保留禁用换图/已有队列限制；无账号登录检查。取到 LocalAvatar 后有空指针分支，不要求必须存在本地角色。 |
| `ChangeLevelWithFade::Update` | `0x9835E4` | 延时淡出后调用 `Game::QueueLevel`；Mod 未直接调用 `LevelLoad`。 |
| `ResourceBundleBarn::TryAccessLevel` | `0xBDF04C` | Mod 使用 request=false 做可用性预检查，不触发 Mod 自己的下载/地址替换。 |
| `Game::LevelExists` | `0xA9AC90` | bundle 不可用会断言/abort；须先做可用性预检查。 |
| `Game::QueueLevel` | `0xA9ABFC` | 原版队列和地图名复制。 |
| `AccountBarn::IsReady() const` | `0x7E3BC0` | `AccountBarn+0xA70 == 23`，不同于 GameMode；Mod 不调用此函数。 |

原 Mod 对照文件为 `source/MineSky/canvas/src/main/cpp/game/CheckpointBarn.cpp`。其版本使用不同 RVA `0x994B4C`，只作为 ABI/行为参考，未照搬此地址到 169938。

## 本地执行条件

`local_scene_ready` 不判断账号、服务端会话、pressed-start 或本地角色是否存在，而是判断：

| 对象/偏移 | 条件 |
|---|---|
| Game `+0x1424` | Ready=2 或 Running=3。旧 mode=2 唯一限制已修正。 |
| Game `+0x160C` | 初始化组掩码的 1/2/4 位均已设置。 |
| Game `+0x1428` / `+0x1448` | 当前地图非空，原版待切地图为空。 |
| Game `+0x1488` | 暂停时仍可提交，但不执行；恢复后再处理。 |
| Game `+0x20` / `+0x170` | Lua state / ResourceManager 非空。 |
| Game `+0x340` / `+0xD0` / `+0x558` | ResourceBundleBarn / Vfs / EventBarn 非空。 |
| ResourceManager `+0x4C0` / `+0x4C8` / `+0x4D8` | pending-load、active-load 和 jobs 均为零。 |

选择期间最后一次请求覆盖前一次；未暂停且等待约 60 秒仍未就绪会提示超时。执行后冷却两秒。资源未就绪或地图不存在会报告拒绝原因。

`Game::UpdateSync` 的 484 行伪代码存在历史自动原型误判：反编译头把栈变量误当成许多参数。ABI 根据实际符号 `_ZN4Game10UpdateSyncEv`、调用点和 ARM64 汇编确认，不能依据那段错误函数头增加参数。本轮没有为此 patch 输入库。

## 登录/联网边界

- 原版 `NetModule::UpdateMatch` 中，账号 `IsReady` 和 `AccountServerClient::HasSession` 仍是联网匹配/空房间请求的前置条件；Mod 没有绕过这些条件。
- 原版 `NetModule::UpdateEmptyGame` 是向账号服务器请求房间，不是本地地图加载器；没有将它当作未登录传送实现。
- 仅提交本地原版换图事件，不声明拥有联网账号、存档同步或角色状态。原版登录错误 UI 可能仍覆盖画面，地图逻辑也可能依赖原版状态。
- 请求已排队/事件已提交不是实际换图成功反馈。再次打开面板显示当前地图可帮助人工观察，但仍须设备实测。

证据：`logs/ida_no_login_update_match.*`、`logs/ida_no_login_empty_game.*`、`logs/ida_no_login_net_update.*`、`logs/ida_no_login_account_on_level_load.json`。

## 地图列表

成品 DEX 内 `TeleportOverlay.readLevels` 调用当前 Activity 的 `AssetManager.list("Data/Levels")`，再打开每张地图的 `Resources.lua`，排除空文件和无效内部名。安装包实际有 51 张。中文映射仅作标签和搜索文本，并非控制显示数量的固定列表。

原生侧重复检查安装包中同一资源非空；不接受路径穿越、中文内部名、空名称或超过 31 字节的名称。

成品验证：`logs/resume_20261107_dex_verification.json`；早期同类记录 `logs/no_login_dex_verification.json` 是历史快照，以本轮实际 DEX 解析结果为准。

## 验证结果与局限

1. 重新编译 C 与 Java/D8 成功，新增库和 DEX 与 APK 内文件 **逐字节相同**，见 `logs/resume_20261107_rebuild.json`。
2. 42 项检查通过：**41 项新增原生库 ARM64 模拟执行场景 + 1 项 Java 源码检查**。Android/JNI、mutex 和所有原版游戏调用为桩；并非 42 个真机场景，也不证明线程竞争安全或完整引擎换图成功。
3. 独立解析成品 DEX，确认直接选图请求、无 `nativeReady` 门槛、继承原 Application 和 51 张动态地图。
4. 官方 apksigner v2/v3 验证和 zipalign 验证通过。全部 ZIP CRC 通过，5155 个原条目内容保留；原版游戏库未替换。
5. 原 APK 单条音频 CRC 错误只修正 ZIP 元数据，内容未修改。移除原 SourceStamp；清单只替换 Application 字符串。
6. 本轮未调用 ADB，未安装、卸载或清除应用数据；没有真机运行证据。

完整机器可读报告：`ida_no_login_review.json`、`verification.json`、`native_tests.json`、`build_environment.json`。

## 交付

- 使用说明：`README.txt`；外部副本 `E:\sky-children-of-the-light-0-13-4-169938_teleport-no-login_说明.txt`。
- 源码压缩包：`E:\sky-children-of-the-light-0-13-4-169938_teleport-no-login_源码.zip`，单一项目根目录，不混入旧版文件。
- APK 校验文件：`E:\sky-children-of-the-light-0-13-4-169938_teleport-no-login.apk.sha256`。
- 源码包不含原 APK/游戏资源、IDA IDB、签名私钥或大体积 JDK/SDK/NDK。构建准备和限制见 `BUILD.md`。
