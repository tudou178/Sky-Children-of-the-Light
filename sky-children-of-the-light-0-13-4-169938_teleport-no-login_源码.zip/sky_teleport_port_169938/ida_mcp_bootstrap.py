"""Start a project-local IDA MCP endpoint; never modify APK/game bytes."""
import json
import os
import pathlib
import sys
import traceback

W = pathlib.Path(__file__).resolve().parent
LOG = W / 'logs' / 'ida_mcp_bootstrap.log'

def log(message):
    with LOG.open('a', encoding='utf-8') as f:
        f.write(message + '\n')
    print('[Sky169938 MCP] ' + message, flush=True)

try:
    import idaapi
    import ida_auto
    import ida_nalt
    import idc
    log('PID=%d IDA=%s Python=%s Input=%s' % (
        os.getpid(), idaapi.get_kernel_version(), sys.version, ida_nalt.get_input_file_path()))
    sys.path.insert(0, str(W / 'tools' / 'ida-mcp-source' / 'src' / 'ida_pro_mcp'))
    os.environ['IDA_MCP_TOOL_TIMEOUT_SEC'] = '180'
    from ida_mcp import MCP_SERVER, IdaMcpHttpRequestHandler
    from ida_mcp.rpc import set_download_base_url
    allowed = {
        'server_health', 'server_warmup', 'lookup_funcs', 'int_convert',
        'list_funcs', 'list_globals', 'imports', 'decompile', 'disasm',
        'xrefs_to', 'callees', 'get_bytes', 'get_int', 'get_string',
        'get_global_value', 'find_regex', 'find_bytes', 'basic_blocks',
        'export_funcs', 'py_eval', 'idb_save', 'stack_frame',
    }
    MCP_SERVER.tools.methods = {
        name: func for name, func in MCP_SERVER.tools.methods.items() if name in allowed
    }
    set_download_base_url('http://127.0.0.1:13337')
    MCP_SERVER.serve('127.0.0.1', 13337, request_handler=IdaMcpHttpRequestHandler)
    log('MCP ready at http://127.0.0.1:13337/mcp ; tools=' + ','.join(sorted(MCP_SERVER.tools.methods)))
    (W / 'logs' / 'ida_mcp_endpoint.json').write_text(json.dumps({
        'pid': os.getpid(), 'endpoint': 'http://127.0.0.1:13337/mcp',
        'input': ida_nalt.get_input_file_path(), 'idb': idc.get_idb_path(),
        'ida_version': idaapi.get_kernel_version(), 'admin_launcher': True,
        'scope': 'loopback only; project-local MCP; no game server'
    }, indent=2), encoding='utf-8')
except Exception:
    log(traceback.format_exc())
