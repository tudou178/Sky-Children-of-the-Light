"""Package the no-login-gate source/evidence release; never rewrite an APK.

The source ZIP has exactly one project root and excludes original game inputs,
SDK/NDK/JDK, IDA databases, user/session files and signing private material.
"""
import hashlib
import json
import pathlib
import zipfile

W = pathlib.Path(__file__).resolve().parent
ROOT = 'sky_teleport_port_169938'
APK = pathlib.Path(r'E:\sky-children-of-the-light-0-13-4-169938_teleport-no-login.apk')
BASENAME = APK.stem
SOURCE_ZIP = APK.with_name(BASENAME + '_源码.zip')
README_OUT = APK.with_name(BASENAME + '_说明.txt')


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while data := f.read(8 << 20):
            h.update(data)
    return h.hexdigest()


def write_new_or_identical(path, data):
    if path.exists():
        if path.read_bytes() != data:
            raise RuntimeError('Refusing to overwrite different existing file: ' + str(path))
        print('UNCHANGED', path)
        return
    with path.open('xb') as f:
        f.write(data)
    print('WROTE', path)


def selected_files():
    names = [
        'README.txt', 'IDA_NO_LOGIN_REVIEW.md', 'ida_no_login_review.json',
        'BUILD.md', 'THIRD_PARTY_NOTICES.md', 'requirements-review.txt',
        'build_environment.json', 'verification.json', 'native_tests.json',
        'target_levels.json', 'build_native.py', 'build_java.py', 'build_apk.py',
        'verify_apk.py', 'test_native_arm64.py', 'package_no_login_release.py',
        'Start-IdaMcp.ps1', 'ida_mcp_bootstrap.py', 'ida_mcp_client.py',
        'build/libskyteleport.so', 'build/dex/classes.dex',
        'build/stubs/com/tgc/sky/TGCApplication.java',
        'tools/shadowhook-classes.jar', 'tools/shadowhook-1.0.7.aar',
        'tools/ida-mcp-source/LICENSE', 'logs/ida_mcp_source.json',
    ]
    paths = {W / n for n in names}
    paths.update(p for p in (W / 'mod').rglob('*') if p.is_file())
    paths.update(p for p in (W / 'licenses').rglob('*') if p.is_file())
    paths.update((W / 'tools/ida-mcp-source/src/ida_pro_mcp/ida_mcp').rglob('*.py'))
    # This round's independent rebuild, DEX, signature, CRC and MCP results.
    for pattern in ['resume_20261107_*', 'ida_mcp_resume_20261107_*',
                    'ida_resume_20261107_*']:
        paths.update((W / 'logs').glob(pattern))
    # Relevant raw evidence from the preceding implementation session.
    offline = ['game_initialize', 'game_initialize_mask', 'update_sync',
               'game_mode_names', 'game_update_disasm', 'fade_start', 'fade_update',
               'bundle_access', 'account_ready', 'queue_level', 'game_pause_state',
               'event_barn_update', 'game_level_load', 'home_level',
               'default_level_queue', 'meta_fields', 'modules_lookup']
    for label in offline:
        paths.update((W / 'logs').glob('ida_mcp_offline_' + label + '.json'))
        paths.update((W / 'logs').glob('ida_offline_' + label + '.*'))
    for label in ['net_update', 'empty_game', 'original_change', 'update_match',
                  'account_on_level_load', 'function_evidence']:
        paths.update((W / 'logs').glob('ida_mcp_no_login_' + label + '.json'))
        paths.update((W / 'logs').glob('ida_no_login_' + label + '.*'))
    files = []
    for path in sorted(paths):
        if not path.is_file():
            raise FileNotFoundError(path)
        rel = path.relative_to(W).as_posix()
        if ('__pycache__' in rel.split('/') or rel.startswith(('signing/', 'target/', 'source/', 'donor/'))
                or path.suffix.lower() in {'.apk', '.i64', '.id0', '.id1', '.id2', '.nam', '.til', '.pk8', '.pem', '.pyc'}):
            raise RuntimeError('Forbidden source-archive file: ' + rel)
        files.append((rel, path))
    return files


def validate_archive(path, payloads):
    with zipfile.ZipFile(path) as z:
        assert z.namelist() == sorted(payloads), 'Unexpected or duplicate archive entries'
        assert z.testzip() is None
        for name, data in payloads.items():
            assert z.read(name) == data, name


def main():
    report = json.loads((W / 'ida_no_login_review.json').read_text(encoding='utf-8'))
    verification = json.loads((W / 'verification.json').read_text(encoding='utf-8'))
    tests = json.loads((W / 'native_tests.json').read_text(encoding='utf-8'))
    apk_hash = sha256(APK)
    assert apk_hash == verification['apk_sha256'] == report['verification']['apk_sha256']
    assert tests['tests_passed'] == 42 and tests['native_emulation_cases'] == 41 and tests['java_source_checks'] == 1
    assert not tests['original_game_functions_executed'] and not tests['device_runtime_tested']
    assert report['ida_mcp']['patched_game_bytes_count'] == 0
    assert report['scope']['mod_login_gate_removed'] and not report['scope']['local_game_server_added']
    assert tests['mod_sha256'] == sha256(W / 'build/libskyteleport.so')
    with zipfile.ZipFile(APK) as z:
        assert z.read('lib/arm64-v8a/libskyteleport.so') == (W / 'build/libskyteleport.so').read_bytes()
        assert z.read('classes3.dex') == (W / 'build/dex/classes.dex').read_bytes()
    for old, expected in report['historical_release_preservation'].items():
        path = pathlib.Path(old)
        assert path.stat().st_size == expected['size'] and sha256(path) == expected['sha256'], old
    # Snapshot all selected content before writing the release ZIP.
    files = selected_files()
    payloads = {ROOT + '/' + rel: p.read_bytes() for rel, p in files}
    assert len(payloads) == len(files)
    manifest = {
        'variant': 'teleport-no-login / no Mod login gate',
        'apk_sha256': apk_hash,
        'original_game_resources_included': False,
        'private_signing_material_included': False,
        'ida_database_included': False,
        'jdk_sdk_ndk_included': False,
        'device_runtime_tested': False,
        'files': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                  for name, data in sorted(payloads.items())},
    }
    payloads[ROOT + '/SOURCE_MANIFEST.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8')
    if SOURCE_ZIP.exists():
        validate_archive(SOURCE_ZIP, payloads)
        print('UNCHANGED', SOURCE_ZIP)
    else:
        # Exclusive creation protects old or unexpected user outputs.
        with zipfile.ZipFile(SOURCE_ZIP, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for name, data in sorted(payloads.items()):
                item = zipfile.ZipInfo(name, date_time=(2026, 11, 7, 0, 0, 0))
                item.compress_type = zipfile.ZIP_DEFLATED
                item.create_system = 3
                item.external_attr = 0o100644 << 16
                z.writestr(item, data)
        validate_archive(SOURCE_ZIP, payloads)
        print('WROTE', SOURCE_ZIP)
    write_new_or_identical(README_OUT, (W / 'README.txt').read_bytes())
    source_hash = sha256(SOURCE_ZIP)
    write_new_or_identical(APK.with_suffix(APK.suffix + '.sha256'),
                           (apk_hash + '  ' + APK.name + '\n').encode('utf-8'))
    write_new_or_identical(SOURCE_ZIP.with_suffix(SOURCE_ZIP.suffix + '.sha256'),
                           (source_hash + '  ' + SOURCE_ZIP.name + '\n').encode('utf-8'))
    delivery = {'apk': {'path': str(APK), 'size': APK.stat().st_size, 'sha256': apk_hash},
                'source_zip': {'path': str(SOURCE_ZIP), 'size': SOURCE_ZIP.stat().st_size,
                               'entries': len(payloads), 'sha256': source_hash,
                               'crc_verified': True, 'single_root': ROOT,
                               'source_bytes_verified': True, 'private_signing_material_included': False},
                'readme': str(README_OUT), 'historical_release_preserved': True,
                'device_runtime_tested': False}
    write_new_or_identical(W / 'logs/no_login_delivery.json',
                           json.dumps(delivery, ensure_ascii=False, indent=2).encode('utf-8'))
    print(json.dumps(delivery, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
