﻿import pathlib,zipfile,struct,hashlib,json,time
from loguru import logger
logger.remove()
from androguard.core.axml import AXMLPrinter
from lxml import etree
W=pathlib.Path(__file__).resolve().parent
src=pathlib.Path(r'E:\sky-children-of-the-light-0-13-4-169938.apk')
dst=pathlib.Path(r'E:\sky-children-of-the-light-0-13-4-169938_teleport-no-login.apk')
report={}; start=time.monotonic()
with zipfile.ZipFile(src) as a,zipfile.ZipFile(dst) as b,src.open('rb') as af,dst.open('rb') as bf:
 ai={x.filename:x for x in a.infolist()}; bi={x.filename:x for x in b.infolist()}
 report['added']=sorted(bi.keys()-ai.keys()); report['removed']=sorted(ai.keys()-bi.keys())
 assert report['removed']==['stamp-cert-sha256'],report['removed']
 # apksigner deliberately removes the stale original SourceStamp cert digest.
 assert set(report['added'])=={'classes3.dex','lib/arm64-v8a/libskyteleport.so','lib/arm64-v8a/libshadowhook.so'}
 changes=[]; metadata_fixes=[]; preserved=0
 def compressed_hash(f,i):
  f.seek(i.header_offset+26); n,e=struct.unpack('<HH',f.read(4)); f.seek(i.header_offset+30+n+e)
  h=hashlib.sha256(); left=i.compress_size
  while left:
   v=f.read(min(8<<20,left)); assert v; h.update(v); left-=len(v)
  return h.digest()
 for index,(n,i) in enumerate(ai.items()):
  if n in report['removed']: continue
  j=bi[n]
  if i.file_size!=j.file_size or i.compress_type!=j.compress_type or compressed_hash(af,i)!=compressed_hash(bf,j):
   changes.append(n)
  else:
   preserved+=1
   if i.CRC!=j.CRC:
    assert n=='assets/Data/Audio/Fmod/fmodandroid/Music_AP11.streams.bank'
    assert i.CRC==0x8BC44108 and j.CRC==0x3A70DF6B
    metadata_fixes.append({'name':n,'old_crc':hex(i.CRC),'new_crc':hex(j.CRC),'payload_unchanged':True})
  if (index+1)%1000==0: print('Compared',index+1,'entries',flush=True)
 assert changes==['AndroidManifest.xml'],changes
 assert len(metadata_fixes)==1,metadata_fixes
 report['changed_file_contents']=changes
 report['byte_identical_original_file_contents']=preserved
 report['zip_metadata_fixes']=metadata_fixes
 ar=AXMLPrinter(a.read('AndroidManifest.xml')).get_xml_obj(); br=AXMLPrinter(b.read('AndroidManifest.xml')).get_xml_obj(); ns='{http://schemas.android.com/apk/res/android}'
 assert br.find('application').get(ns+'name')=='sky.teleport.TeleportApplication'
 report['package']=br.get('package'); report['version_code']=br.get(ns+'versionCode'); report['version_name']=br.get(ns+'versionName')
 br.find('application').set(ns+'name','com.tgc.sky.TGCApplication'); assert etree.tostring(ar)==etree.tostring(br)
 report['manifest_only_application_changed']=True
 for n in ['classes.dex','classes2.dex','resources.arsc','lib/arm64-v8a/libBootloader.so','classes3.dex','lib/arm64-v8a/libskyteleport.so','lib/arm64-v8a/libshadowhook.so']:
  report.setdefault('entry_sha256',{})[n]=hashlib.sha256(b.read(n)).hexdigest()
 print('PASS exact preservation:',preserved,'original entries;',changes,'only changed; stale SourceStamp removed')
 print('PASS no donor launcher, login/server config or game-library replacement')
 print('Testing every ZIP entry CRC...',flush=True); bad=b.testzip(); assert bad is None,bad; report['zip_crc_verified']=True
 report['apk_size']=dst.stat().st_size
h=hashlib.sha256()
with dst.open('rb') as f:
 while v:=f.read(8<<20): h.update(v)
report['apk_sha256']=h.hexdigest(); report['seconds']=round(time.monotonic()-start,2)
(W/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
