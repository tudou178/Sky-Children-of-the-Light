﻿import pathlib,subprocess,json
W=pathlib.Path(__file__).resolve().parent
N=W/'tools/sdk/android-ndk-r25c/toolchains/llvm/prebuilt/windows-x86_64'
cmd=[str(N/'bin/clang.exe'),'--target=aarch64-linux-android26','-std=c11','-O2',
 '-Wall','-Wextra','-Werror','-fPIC','-fvisibility=hidden','-ffunction-sections','-fdata-sections',
 '-I',str(W/'mod/native/include'),'-shared',str(W/'mod/native/skyteleport.c'),
 '-L',str(W/'mod/native/lib'),'-lshadowhook','-llog','-landroid','-ldl',
 '-Wl,--gc-sections','-Wl,-z,relro','-Wl,-z,now','-Wl,-z,noexecstack','-Wl,-z,max-page-size=16384',
 '-Wl,--build-id=sha1','-Wl,--no-undefined','-Wl,-soname,libskyteleport.so',
 '-o',str(W/'build/libskyteleport.so')]
r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(W/'logs/native_compile.txt').write_bytes(r.stdout)
print(r.stdout.decode('utf-8',errors='replace')); print('Native compile:',r.returncode)
if r.returncode: raise SystemExit(r.returncode)
print('ARM64 library:',(W/'build/libskyteleport.so').stat().st_size,'bytes')
