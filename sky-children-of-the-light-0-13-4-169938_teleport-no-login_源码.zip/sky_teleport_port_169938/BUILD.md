# 构建与复核

本目录是 Sky 0.13.4 (169938) 地图传送无登录门槛版的可复核源码。当前目录已具备工具和提取输入；源码 ZIP 为小体积交付，不包含原 APK、原游戏库/资源、IDA 数据库、私钥或大体积 JDK/SDK/NDK。

## 已使用的环境

- Windows x64、Python 3.14.7。
- Azul Zulu JDK 17.0.21.0.3，`tools/jdk/<jdk-directory>/bin`。
- Android platform 30 的 `android.jar`，脚本现使用 `tools/sdk/android-11/android.jar`（压缩包原目录名）。
- Android build-tools 34.0.0，脚本现使用 `tools/sdk/android-14`（压缩包原目录名）。
- Android NDK r25c / 25.2.9519653，`tools/sdk/android-ndk-r25c`，Clang 14.0.7。
- 原生目标 `aarch64-linux-android26`。
- Shadowhook 1.0.7 的官方 AAR、ARM64 库、头文件与 classes.jar。
- Python 依赖及实际版本记录于 `build_environment.json`，也列在 `requirements-review.txt`。

这些工具只用于本机编译/分析，不作为服务器运行，也不加入 APK。SDK/NDK/JDK 压缩包哈希见 `build_environment.json`。旧 `download_tools.py` 是之前的下载尝试脚本，不适合作为本版完整准备器，未收入交付源码包。

## 从源码 ZIP 准备

1. 解压后得到唯一根目录 `sky_teleport_port_169938`，保留子目录结构。
2. 使用你提供的原始 `E:\sky-children-of-the-light-0-13-4-169938.apk`，不要使用修改版代替输入。若路径不同，修改 `build_apk.py` / `verify_apk.py` 的路径常量。
3. 自行准备上述官方工具，放在脚本期望的位置；不要把 API 30 与 build-tools 34 的目录误认成版本号 11/14。
4. 建立 Python 环境并安装 `requirements-review.txt` 中依赖。精确版本对应此次环境，不代表其他平台也兼容。
5. 创建 `build` 和 `logs` 目录，并从原 APK 提取最小输入：

```powershell
python -c "import pathlib,zipfile; w=pathlib.Path.cwd(); (w/'build').mkdir(exist_ok=True); (w/'logs').mkdir(exist_ok=True); z=zipfile.ZipFile(r'E:\sky-children-of-the-light-0-13-4-169938.apk'); [(w/'target'/n).parent.mkdir(parents=True,exist_ok=True) or (w/'target'/n).write_bytes(z.read(n)) for n in ['AndroidManifest.xml','lib/arm64-v8a/libBootloader.so']]; z.close()"
```

不会读取已知 CRC 错误的音频条目。原包保留在原位置，不修改或覆盖。

编译用 `build/stubs/com/tgc/sky/TGCApplication.java` 只是 javac 类路径桩；`build_java.py` 不会将该桩类打入新增 DEX，运行时使用原版 DEX 的 TGCApplication。

## 编译和检查

```powershell
python build_native.py
python build_java.py
python test_native_arm64.py
```

`test_native_arm64.py` 使用原输入库的符号/字节作版本检查，但拦截并桩化所有原版游戏函数；它没有执行完整原版游戏，也不提供设备运行保证。

在当前工作目录重新编译后，原生库和新增 DEX 已确认与交付 APK 对应文件相同。具体哈希见 `logs/resume_20261107_rebuild.json`。

## APK 打包与签名

```powershell
python build_apk.py
python verify_apk.py
```

- `build_apk.py` 拒绝覆盖已存在的输出 APK；不要为重现构建而删除用户的成品。需要另一个输出时，修改 `OUT`，并同步修改 `verify_apk.py` 的 `dst`。
- 原条目的压缩数据直接保留；清单只替换 Application，新增一份 DEX 和两份原生库。
- 对齐由脚本写入 ZIP 时处理，再用官方 zipalign 检查；签名为 v2/v3。
- 本机保留签名材料于 `signing`，**不收入源码 ZIP**。在新目录构建会生成新证书，因此最终 APK 整体哈希和覆盖安装条件会不同；没有原签名私钥不能逐字节重现现有签名。
- 打包过程只更正原输入音频条目的 ZIP CRC 元数据，不改变音频内容，并移除旧 SourceStamp 元数据。
- 复核辅助脚本和报告不加入 APK。未包含 donor 原包的私服启动器或其他功能。

签名/对齐结果见 `logs/resume_20261107_signature_verify.txt` 和 `logs/resume_20261107_alignment_verify.txt`。

## IDA / MCP（可选本机复核）

需要合法安装的 IDA 9.3 和相应 ARM64 反编译能力。`Start-IdaMcp.ps1` 在未提权时用正常 UAC 请求管理员授权；若端口已占用则不停止任何进程。

- 输入 `target/lib/arm64-v8a/libBootloader.so`，IDB `build/ida/sky169938.i64`。
- MCP 插件 Python 源码只在项目内 `tools/ida-mcp-source/src/ida_pro_mcp/ida_mcp`。
- 监听 `127.0.0.1:13337`，客户端 `ida_mcp_client.py` 不使用系统代理。
- 只连接确认属于本项目的端点，不操作其他后台 IDA。
- `py_eval` 可执行 IDAPython，并不是操作系统隔离边界；仅在可信本机场景使用。
- 当前任务不需要 ADB，不要将模拟测试等同真机验证。

## 源码打包

`python package_no_login_release.py` 把当前说明、源码、固定 MCP Python 源码及本轮证据打到单一项目根目录下，同时写出 APK/ZIP 的 SHA-256 文件。不收入原包/资源、IDA IDB、SDK/JDK/NDK、会话历史或私钥。它会先检查 APK 哈希和源码构建字节一致性；输出已存在且不同则拒绝覆盖。
