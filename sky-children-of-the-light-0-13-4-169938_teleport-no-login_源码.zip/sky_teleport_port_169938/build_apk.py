﻿"""Reproduce the map-only APK from the untouched 169938 input.
Only the Application-name string is changed; original DEX/native/assets are
raw-copied. Add one DEX plus libskyteleport/libshadowhook, align and sign with
Google's apksigner (v2/v3). Never modify or overwrite either source APK.
"""
import datetime
import hashlib
import io
import json
import pathlib
import re
import struct
import subprocess
import zipfile
import zlib
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa

WORK = pathlib.Path(__file__).resolve().parent
SRC = pathlib.Path(r'E:\sky-children-of-the-light-0-13-4-169938.apk')
OUT = pathlib.Path(r'E:\sky-children-of-the-light-0-13-4-169938_teleport-no-login.apk')
UNSIGNED = WORK / 'build/teleport-no-login-unsigned.apk'
REPLACEMENT = 'sky.teleport.TeleportApplication'
ANDROID = WORK / 'tools/sdk/android-14'
JAVA = next((WORK / 'tools/jdk').glob('*/bin/java.exe'))


def replace_manifest_application(blob):
    # Original UTF-16 string-pool indices stay stable. No activity/permission/
    # SDK/server/network-security entries are rewritten or transplanted.
    assert blob[:4] == b'\x03\x00\x08\x00'
    off = 8
    typ, header, size = struct.unpack_from('<HHI', blob, off)
    assert typ == 1 and header == 28
    count, styles, flags, string_start, style_start = struct.unpack_from('<IIIII', blob, off + 8)
    assert styles == 0 and not flags & 0x100 and style_start == 0
    strings = []
    for i in range(count):
        start = struct.unpack_from('<I', blob, off + header + i * 4)[0] + off + string_start
        ln = struct.unpack_from('<H', blob, start)[0]
        start += 2
        if ln & 0x8000:
            ln = ((ln & 0x7fff) << 16) | struct.unpack_from('<H', blob, start)[0]
            start += 2
        strings.append(blob[start:start + ln * 2].decode('utf-16-le'))
    indices = [i for i, s in enumerate(strings) if s == 'com.tgc.sky.TGCApplication']
    assert len(indices) == 1, indices
    strings[indices[0]] = REPLACEMENT
    raw = bytearray()
    offsets = []
    for s in strings:
        data = s.encode('utf-16-le')
        n = len(data) // 2
        offsets.append(len(raw))
        if n < 0x8000:
            raw += struct.pack('<H', n)
        else:
            raw += struct.pack('<HH', 0x8000 | (n >> 16), n & 0xffff)
        raw += data + b'\0\0'
    raw += b'\0' * ((-len(raw)) & 3)
    start = header + len(offsets) * 4
    new_size = start + len(raw)
    pool = struct.pack('<HHIIIIII', 1, header, new_size, count, 0, flags, start, 0)
    pool += struct.pack('<' + 'I' * count, *offsets) + raw
    result = bytearray(blob[:off] + pool + blob[off + size:])
    struct.pack_into('<I', result, 4, len(result))
    return bytes(result)


def eocd_and_cd(fp):
    fp.seek(0, 2)
    total = fp.tell()
    fp.seek(max(0, total - 65557))
    tail = fp.read()
    off = tail.rfind(b'PK\x05\x06')
    assert off >= 0
    fields = struct.unpack_from('<IHHHHIIH', tail, off)
    _, disk, cddisk, nthis, nent, cdsize, cdstart, comment_len = fields
    assert disk == 0 and cddisk == 0 and nthis == nent
    assert total - len(tail) + off + 22 + comment_len == total
    fp.seek(cdstart)
    cd = fp.read(cdsize)
    entries = []
    p = 0
    for _ in range(nent):
        assert cd[p:p+4] == b'PK\x01\x02'
        values = struct.unpack_from('<IHHHHHHIIIHHHHHII', cd, p)
        (sig, made, needed, flags, method, tm, date, crc, csize, usize,
         nlen, elen, clen, dnum, iattr, eattr, localoff) = values
        name = cd[p+46:p+46+nlen]
        entries.append(dict(made=made, needed=needed, flags=flags, method=method,
                            tm=tm, date=date, crc=crc, csize=csize, usize=usize,
                            name=name, iattr=iattr, eattr=eattr, localoff=localoff))
        p += 46 + nlen + elen + clen
    assert p == len(cd)
    return entries


def compressed(blob):
    obj = zlib.compressobj(9, zlib.DEFLATED, -15)
    return obj.compress(blob) + obj.flush()


def write_unsigned():
    manifest = (WORK / 'target/AndroidManifest.xml').read_bytes()
    replacements = {b'AndroidManifest.xml': replace_manifest_application(manifest)}
    (WORK / 'build/AndroidManifest_patched.xml').write_bytes(replacements[b'AndroidManifest.xml'])
    additions = {
        b'classes3.dex': (WORK / 'build/dex/classes.dex').read_bytes(),
        b'lib/arm64-v8a/libskyteleport.so': (WORK / 'build/libskyteleport.so').read_bytes(),
        b'lib/arm64-v8a/libshadowhook.so': (WORK / 'mod/native/lib/libshadowhook.so').read_bytes(),
    }
    # The supplied APK contains one pre-existing CRC mismatch. Correct only
    # ZIP header/central-directory metadata, retaining every audio payload byte.
    checksum_fixes = {
        b'assets/Data/Audio/Fmod/fmodandroid/Music_AP11.streams.bank':
            (0x8BC44108, 0x3A70DF6B, 11069984),
    }
    records = []
    with SRC.open('rb') as src, UNSIGNED.open('wb') as dst:
        entries = eocd_and_cd(src)
        assert not any(e['name'] in additions for e in entries)
        kept = [e for e in entries if not re.match(rb'^META-INF/(?:[^/]+\.(?:SF|RSA|DSA|EC)|MANIFEST\.MF)$', e['name'], re.I)]
        print('Original entries:', len(entries), 'kept:', len(kept), flush=True)
        def emit(e, payload=None, store=False):
            # Copy compressed original bytes without decompression/recompression.
            old_off = e['localoff']
            flags = e['flags'] & ~8
            name = e['name']
            if payload is None:
                src.seek(old_off)
                lh = src.read(30)
                assert lh[:4] == b'PK\x03\x04'
                ln, le = struct.unpack_from('<HH', lh, 26)
                src.seek(old_off + 30 + ln + le)
                method, crc, csize, usize = e['method'], e['crc'], e['csize'], e['usize']
                if name in checksum_fixes:
                    old_crc, new_crc, expected_size = checksum_fixes[name]
                    assert crc == old_crc and usize == expected_size and method == 0
                    crc = new_crc
                    print('Corrected existing CRC metadata:', name.decode(),
                          hex(old_crc), '->', hex(new_crc), flush=True)
                data = None
            else:
                method = 0 if store else 8
                crc = zlib.crc32(payload) & 0xffffffff
                usize = len(payload)
                data = payload if store else compressed(payload)
                csize = len(data)
            localoff = dst.tell()
            extra = b''
            if method == 0:
                align = 16384 if name.endswith(b'.so') else 4
                base = localoff + 30 + len(name)
                if base % align:
                    pad = (align - ((base + 6) % align)) % align
                    extra = struct.pack('<HHH', 0xd935, 2 + pad, align) + b'\0' * pad
                assert (base + len(extra)) % align == 0
            lh = struct.pack('<IHHHHHIIIHH', 0x04034b50, e['needed'], flags, method,
                             e['tm'], e['date'], crc, csize, usize, len(name), len(extra))
            dst.write(lh + name + extra)
            if data is not None:
                dst.write(data)
            else:
                left = csize
                copied_crc = 0
                while left:
                    b = src.read(min(left, 8 << 20))
                    assert b
                    dst.write(b)
                    if name in checksum_fixes: copied_crc = zlib.crc32(b, copied_crc)
                    left -= len(b)
                if name in checksum_fixes: assert (copied_crc & 0xffffffff) == crc
            records.append(struct.pack('<IHHHHHHIIIHHHHHII', 0x02014b50,
                 e['made'], e['needed'], flags, method, e['tm'], e['date'],
                 crc, csize, usize, len(name), 0, 0, 0, e['iattr'], e['eattr'], localoff) + name)
        for i, e in enumerate(kept):
            emit(e, replacements.get(e['name']))
            if (i + 1) % 1000 == 0: print('Copied', i + 1, '/', len(kept), flush=True)
        for name, payload in additions.items():
            e = dict(made=20, needed=20, flags=0x800, method=8, tm=0, date=0x5ce7,
                     crc=0, csize=0, usize=0, name=name, iattr=0, eattr=0, localoff=0)
            emit(e, payload, store=name.endswith(b'.so'))
            print('Added', name.decode(), len(payload), 'bytes', flush=True)
        cdstart = dst.tell()
        cd = b''.join(records)
        assert len(records) < 65535 and cdstart < 0xffffffff
        dst.write(cd)
        dst.write(struct.pack('<IHHHHIIH', 0x06054b50, 0, 0, len(records), len(records), len(cd), cdstart, 0))
    print('Unsigned APK:', UNSIGNED, UNSIGNED.stat().st_size, flush=True)


def get_signing_material():
    directory = WORK / 'signing'
    directory.mkdir(exist_ok=True)
    keyfile = directory / 'teleport_key.pk8'
    certfile = directory / 'teleport_cert.der'
    if not keyfile.exists() or not certfile.exists():
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'Sky 169938 Map-Only Mod')])
        cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
            .public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(datetime.datetime(2026, 1, 1, tzinfo=datetime.timezone.utc))
            .not_valid_after(datetime.datetime(2056, 1, 1, tzinfo=datetime.timezone.utc))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .sign(key, hashes.SHA256()))
        keyfile.write_bytes(key.private_bytes(serialization.Encoding.DER,
             serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        certfile.write_bytes(cert.public_bytes(serialization.Encoding.DER))
        (directory / 'teleport_cert.pem').write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    return keyfile, certfile


def main():
    assert SRC.resolve() != OUT.resolve()
    if OUT.exists():
        raise SystemExit('Output already exists; refusing to overwrite: ' + str(OUT))
    write_unsigned()
    align_cmd = [str(ANDROID / 'zipalign.exe'), '-c', '-p', '-v', '4', str(UNSIGNED)]
    r = subprocess.run(align_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (WORK / 'logs/zipalign.txt').write_bytes(r.stdout)
    print('zipalign:', r.returncode, r.stdout.decode(errors='replace').splitlines()[-1], flush=True)
    if r.returncode: raise RuntimeError('zipalign failed')
    key, cert = get_signing_material()
    cmd = [str(JAVA), '-Duser.language=en', '-Dfile.encoding=UTF-8', '-jar', str(ANDROID / 'lib/apksigner.jar'),
           'sign', '--key', str(key), '--cert', str(cert), '--min-sdk-version', '26',
           '--v1-signing-enabled', 'false', '--v2-signing-enabled', 'true',
           '--v3-signing-enabled', 'true', '--v4-signing-enabled', 'false', '--out', str(OUT), str(UNSIGNED)]
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (WORK / 'logs/apksigner_sign.txt').write_bytes(r.stdout)
    print(r.stdout.decode('utf-8', errors='replace'), 'apksigner sign:', r.returncode, flush=True)
    if r.returncode: raise RuntimeError('APK signing failed')
    print('SIGNED APK:', OUT, OUT.stat().st_size, flush=True)


if __name__ == '__main__':
    main()
