# 第三方声明

## Shadowhook 1.0.7

项目来源：https://github.com/bytedance/android-inline-hook 。本包保存官方 AAR 的 ARM64 库、classes.jar 和头文件；头文件完整保留 ByteDance 的 MIT 授权声明。单独的声明见 `licenses/SHADOWHOOK-MIT.txt`。这里的源码 ZIP 不冒充 Shadowhook 的完整上游源码。

## ida-pro-mcp

项目来源：https://github.com/mrexodia/ida-pro-mcp ，固定提交 `c133c3853faa111a9b00ee615c013b720d0c4acd`。仅项目内使用；本包包含启动器需要的 `ida_mcp` Python 源码及 MIT LICENSE，不包含 IDA 本体、IDB 或许可证。来源/压缩包哈希见 `logs/ida_mcp_source.json`。

## MineSky 与原版游戏

所提供 MineSky 源码用于核对 CheckpointBarn 的调用 ABI，未将其完整启动器或服务端功能收入 APK/源码包。原版 Sky APK、游戏库和资源仍由用户原输入提供，不包含在源码 ZIP 中。

## 构建工具

JDK、Android SDK/NDK、Python 及依赖均使用各自许可证。大体积构建工具不包含在本源码包中，实际环境和哈希记录见 `build_environment.json`。
